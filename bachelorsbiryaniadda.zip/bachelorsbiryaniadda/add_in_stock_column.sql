-- Add in_stock column to menu_items table if it doesn't exist
USE bachelorsbiryani_db;

-- Add the in_stock column
ALTER TABLE menu_items 
ADD COLUMN IF NOT EXISTS in_stock BOOLEAN DEFAULT true;

-- Update existing records to have in_stock = true
UPDATE menu_items SET in_stock = true WHERE in_stock IS NULL;
