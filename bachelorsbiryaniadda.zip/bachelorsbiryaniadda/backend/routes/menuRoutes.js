const express = require('express');
const router = express.Router();
const menuController = require('../controllers/menuController');
const { verifyToken, isAdmin } = require('../middleware/auth');

// Public routes
router.get('/', menuController.getAllMenuItems);
router.get('/:id', menuController.getMenuItemById);

// Admin routes
router.post('/', verifyToken, isAdmin, menuController.addMenuItem);
router.put('/:id', verifyToken, isAdmin, menuController.updateMenuItem);
router.delete('/:id', verifyToken, isAdmin, menuController.deleteMenuItem);

module.exports = router;
