-- Cleanup script: Remove cart_items table if it exists
-- Project uses only ONE cart table

USE bachelorsbiryani_db;

-- Drop cart_items table if it exists (not used in project)
DROP TABLE IF EXISTS cart_items;

-- Verify cart table exists with correct structure
SELECT 
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE
FROM 
    INFORMATION_SCHEMA.COLUMNS
WHERE 
    TABLE_SCHEMA = 'bachelorsbiryani_db' 
    AND TABLE_NAME = 'cart'
ORDER BY 
    ORDINAL_POSITION;

SELECT 'Cleanup complete! Only cart table is used.' as message;
