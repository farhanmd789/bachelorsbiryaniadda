-- Insert menu items with specific IDs to fix foreign key constraint error
-- This ensures menu_item_id 1-11 exist for cart table

USE bachelorsbiryani_db;

-- Insert menu items (will skip if ID already exists)
INSERT IGNORE INTO menu_items (id, name, description, price, category, image_url, is_available) VALUES
(1, 'Chicken Biryani', 'Fragrant basmati rice cooked with tender chicken pieces and aromatic spices', 250, 'biryani', '../IMAGES/biryani.png', true),
(2, 'Paneer Biryani', 'Aromatic basmati rice layered with marinated paneer cubes and fresh vegetables', 249, 'biryani', '../IMAGES/paneerbiryani.png', true),
(3, 'Mutton Biryani', 'Premium mutton pieces slow-cooked with aromatic basmati rice and spices', 379, 'biryani', '../IMAGES/muttonbiryani.png', true),
(4, 'Apollo Fish', 'Crispy fried fish tossed in spicy tangy sauce with curry leaves', 299, 'starter', '../IMAGES/apollofish.jpg', true),
(5, 'Butter Naan', 'Soft and buttery tandoor-baked flatbread', 30, 'bread', '../IMAGES/butternaanwhitebg.jpg', true),
(6, 'Egg Biryani', 'Flavorful biryani with boiled eggs, aromatic spices and basmati rice', 180, 'biryani', '../IMAGES/eggbiryaniwhitebg.jpg', true),
(7, 'Chicken Tikka Wrap', 'Soft tortilla wrap filled with grilled chicken tikka and fresh vegetables', 189, 'starter', '../IMAGES/bachelorshawarma.png', true),
(8, 'Veg Biryani', 'Delicious biryani made with fresh vegetables and aromatic spices', 180, 'biryani', '../IMAGES/biryani.png', true),
(9, 'Chicken kabab', 'Succulent pieces of chicken grilled over charcoal', 279, 'starter', '../IMAGES/kebab.png', true),
(10, 'Mutton pepper-Fry', 'Spicy and flavorful mutton pieces with pepper', 329, 'starter', '../IMAGES/mutton-pepper-fry.png', true),
(11, 'Prawns biryani', 'Savory rice dish infused with spicy marinated prawns', 269, 'biryani', '../IMAGES/prawn biryani.jpg', true);

-- Verify menu items
SELECT id, name, price, category FROM menu_items ORDER BY id;

SELECT CONCAT('✅ Total menu items: ', COUNT(*)) as status FROM menu_items;
