-- Add new dishes to menu_items table
USE bachelorsbiryani_db;

-- Image 1: Paneer Biryani
INSERT INTO menu_items (name, description, price, image_url, category, rating, in_stock) VALUES
('Paneer Biryani', 'Aromatic basmati rice layered with marinated paneer cubes, fresh vegetables, and fragrant spices. A perfect vegetarian delight with every grain infused with rich flavors.', 249.00, './IMAGES/paneer-biryani.png', 'Biryani', 4.8, true);

-- Image 2 & 3: Chicken Wrap/Roll
INSERT INTO menu_items (name, description, price, image_url, category, rating, in_stock) VALUES
('Chicken Tikka Wrap', 'Soft tortilla wrap filled with succulent grilled chicken tikka pieces, fresh lettuce, onions, and tangy sauce. A perfect on-the-go meal packed with flavors.', 189.00, './IMAGES/chicken-wrap.png', 'Wraps', 4.7, true);

-- Image 4: Chicken 65
INSERT INTO menu_items (name, description, price, image_url, category, rating, in_stock) VALUES
('Chicken 65', 'Spicy and crispy deep-fried chicken pieces marinated in a special blend of South Indian spices, curry leaves, and red chilies. A fiery appetizer that packs a punch.', 299.00, './IMAGES/chicken-65.png', 'Starters', 4.9, true);

-- Image 5: Mutton Biryani
INSERT INTO menu_items (name, description, price, image_url, category, rating, in_stock) VALUES
('Mutton Biryani', 'Premium quality mutton pieces slow-cooked with aromatic basmati rice, saffron, and authentic Hyderabadi spices. Served with raita and garnished with fried onions.', 379.00, './IMAGES/mutton-biryani.png', 'Biryani', 5.0, true);

-- Verify the additions
SELECT * FROM menu_items ORDER BY id DESC LIMIT 5;
