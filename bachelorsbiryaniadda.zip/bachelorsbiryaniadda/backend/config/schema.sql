-- Create Database
CREATE DATABASE IF NOT EXISTS bachelorsbiryani_db;
USE bachelorsbiryani_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(15),
  role ENUM('customer', 'admin') DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Menu Items Table
CREATE TABLE IF NOT EXISTS menu_items (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  image_url VARCHAR(255),
  category VARCHAR(50),
  rating DECIMAL(2,1) DEFAULT 0,
  in_stock BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cart Table
CREATE TABLE IF NOT EXISTS cart (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  menu_item_id INT NOT NULL,
  quantity INT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE
);

-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status ENUM('pending', 'preparing', 'out_for_delivery', 'delivered', 'cancelled') DEFAULT 'pending',
  payment_method VARCHAR(50),
  delivery_address TEXT,
  delivery_time DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order Items Table
CREATE TABLE IF NOT EXISTS order_items (
  id INT PRIMARY KEY AUTO_INCREMENT,
  order_id INT NOT NULL,
  menu_item_id INT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE
);

-- Insert Sample Menu Items
INSERT INTO menu_items (name, description, price, image_url, category, rating, in_stock) VALUES
('Bachelors Biryani', 'Authentic bachelor style biryani with perfect blend of spices and tender meat', 229.00, './IMAGES/biryani.png', 'Biryani', 5.0, true),
('Prawns Biryani', 'Prawns biryani is a savory rice dish that is infused with spicy marinated prawns, layered with fragrant basmati rice', 269.00, './IMAGES/prawn biryani.jpg', 'Biryani', 5.0, true),
('Paneer Biryani', 'Aromatic basmati rice layered with marinated paneer cubes, fresh vegetables, and fragrant spices. A perfect vegetarian delight with every grain infused with rich flavors.', 249.00, './IMAGES/paneerbiryani.png', 'Biryani', 4.8, true),
('Mutton Biryani', 'Premium quality mutton pieces slow-cooked with aromatic basmati rice, saffron, and authentic Hyderabadi spices. Served with raita and garnished with fried onions.', 379.00, './IMAGES/muttonbiryani.png', 'Biryani', 5.0, true),
('Chicken Kabab', 'Diced chicken simmered in aromatic are flavorful and succulent pieces of chicken that are grilled over a charcoal', 279.00, './IMAGES/kebab.png', 'Starters', 5.0, true),
('Mutton Pepper-Fry', 'Mutton Pepper Fry is a spicy and flavorful preparation made with succulent mutton pieces, marinated in a blend', 329.00, './IMAGES/mutton-pepper-fry.png', 'Starters', 5.0, true),
('Chicken 65', 'Spicy and crispy deep-fried chicken pieces marinated in a special blend of South Indian spices, curry leaves, and red chilies. A fiery appetizer that packs a punch.', 299.00, './IMAGES/apollofish.jpg', 'Starters', 4.9, true),
('Chicken Tikka Wrap', 'Soft tortilla wrap filled with succulent grilled chicken tikka pieces, fresh lettuce, onions, and tangy sauce. A perfect on-the-go meal packed with flavors.', 189.00, './IMAGES/bachelorshawarma.png', 'Wraps', 4.7, true);

-- Insert Admin User (password: admin123)
INSERT INTO users (name, email, password, phone, role) VALUES
('Admin', 'admin@bachelorsbiryani.com', '$2a$10$XqZ8J5H3YvH3YvH3YvH3YeK8J5H3YvH3YvH3YvH3YvH3YvH3YvH3Y', '8919439778', 'admin');
