const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function setupDatabase() {
  let connection;
  
  try {
    console.log('🔧 Starting database setup...\n');
    
    // Connect to MySQL without specifying database
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      multipleStatements: true
    });
    
    console.log('✅ Connected to MySQL server');
    
    // Read and execute init.sql
    const initSqlPath = path.join(__dirname, 'config', 'init.sql');
    const initSql = fs.readFileSync(initSqlPath, 'utf8');
    
    console.log('📝 Executing database initialization script...');
    await connection.query(initSql);
    console.log('✅ Database and tables created successfully');
    
    // Switch to the database
    await connection.query(`USE ${process.env.DB_NAME || 'bachelorsbiryani_db'}`);
    
    // Check if menu items exist
    const [menuItems] = await connection.query('SELECT COUNT(*) as count FROM menu_items');
    
    if (menuItems[0].count === 0) {
      console.log('📝 Inserting sample menu items...');
      
      // Insert menu items with specific IDs to match frontend expectations
      const insertMenuItems = `
        INSERT INTO menu_items (id, name, description, price, category, image_url, is_available) VALUES
        (1, 'Chicken Biryani', 'Fragrant basmati rice cooked with tender chicken pieces and aromatic spices', 250, 'biryani', '../IMAGES/biryani.png', true),
        (2, 'Paneer Biryani', 'Aromatic basmati rice layered with marinated paneer cubes and fresh vegetables', 249, 'biryani', '../IMAGES/paneerbiryani.png', true),
        (3, 'Mutton Biryani', 'Premium mutton pieces slow-cooked with aromatic basmati rice and spices', 379, 'biryani', '../IMAGES/muttonbiryani.png', true),
        (4, 'Apollo Fish', 'Crispy fried fish tossed in spicy tangy sauce with curry leaves', 299, 'starter', '../IMAGES/apollofish.jpg', true),
        (5, 'Butter Naan', 'Soft and buttery tandoor-baked flatbread', 30, 'bread', '../IMAGES/butternaanwhitebg.jpg', true),
        (6, 'Egg Biryani', 'Flavorful biryani with boiled eggs, aromatic spices and basmati rice', 180, 'biryani', '../IMAGES/eggbiryaniwhitebg.jpg', true),
        (7, 'Chicken Tikka Wrap', 'Soft tortilla wrap filled with grilled chicken tikka and fresh vegetables', 189, 'starter', '../IMAGES/bachelorshawarma.png', true),
        (8, 'Veg Biryani', 'Delicious biryani made with fresh vegetables and aromatic spices', 180, 'biryani', '../IMAGES/biryani.png', true),
        (9, 'Chicken kabab', 'Succulent pieces of chicken grilled over charcoal', 279, 'starter', '../IMAGES/kebab.png', true),
        (10, 'Mutton pepper-Fry', 'Spicy and flavorful mutton pieces with pepper', 329, 'starter', '../IMAGES/mutton-pepper-fry.png', true),
        (11, 'Prawns biryani', 'Savory rice dish infused with spicy marinated prawns', 269, 'biryani', '../IMAGES/prawn biryani.jpg', true);
      `;
      await connection.query(insertMenuItems);
      console.log('✅ Menu items added with IDs 1-11');
    } else {
      console.log('✅ Menu items already exist');
      
      // Verify menu items have the expected IDs
      const [items] = await connection.query('SELECT id, name FROM menu_items ORDER BY id');
      console.log(`   Found ${items.length} menu items (IDs: ${items.map(i => i.id).join(', ')})`);
    }
    
    // Verify cart table exists
    const [cartTable] = await connection.query(
      "SHOW TABLES LIKE 'cart'"
    );
    
    if (cartTable.length > 0) {
      console.log('✅ Cart table exists');
    } else {
      console.log('❌ Cart table missing - this should not happen!');
    }
    
    // Verify orders table has required columns
    const [orderColumns] = await connection.query(
      "SHOW COLUMNS FROM orders WHERE Field IN ('payment_method', 'delivery_time')"
    );
    
    if (orderColumns.length === 2) {
      console.log('✅ Orders table has all required columns');
    } else {
      console.log('⚠️  Orders table missing columns. Running migration...');
      const migrateSqlPath = path.join(__dirname, 'config', 'migrate.sql');
      if (fs.existsSync(migrateSqlPath)) {
        const migrateSql = fs.readFileSync(migrateSqlPath, 'utf8');
        await connection.query(migrateSql);
        console.log('✅ Migration completed');
      }
    }
    
    console.log('\n🎉 Database setup completed successfully!');
    console.log('\n📊 Database Summary:');
    
    const [users] = await connection.query('SELECT COUNT(*) as count FROM users');
    const [menu] = await connection.query('SELECT COUNT(*) as count FROM menu_items');
    const [orders] = await connection.query('SELECT COUNT(*) as count FROM orders');
    const [cart] = await connection.query('SELECT COUNT(*) as count FROM cart');
    
    console.log(`   Users: ${users[0].count}`);
    console.log(`   Menu Items: ${menu[0].count}`);
    console.log(`   Orders: ${orders[0].count}`);
    console.log(`   Cart Items: ${cart[0].count}`);
    
  } catch (error) {
    console.error('❌ Database setup failed:', error.message);
    console.error('\nTroubleshooting:');
    console.error('1. Make sure MySQL is running');
    console.error('2. Check your .env file for correct database credentials');
    console.error('3. Ensure the MySQL user has proper permissions');
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

// Run the setup
setupDatabase();
