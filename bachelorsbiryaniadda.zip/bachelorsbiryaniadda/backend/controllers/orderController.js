const db = require('../config/database');

// Create new order
exports.createOrder = async (req, res) => {
  let connection;
  
  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const { payment_method, delivery_address, delivery_time } = req.body;

    // Validate required fields
    if (!payment_method || !delivery_address || !delivery_time) {
      await connection.rollback();
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required fields: payment_method, delivery_address, or delivery_time' 
      });
    }

    // Get cart items
    const [cartItems] = await connection.query(
      `SELECT c.menu_item_id, c.quantity, m.price
       FROM cart c
       JOIN menu_items m ON c.menu_item_id = m.id
       WHERE c.user_id = ?`,
      [req.user.id]
    );

    if (cartItems.length === 0) {
      await connection.rollback();
      return res.status(400).json({ success: false, message: 'Cart is empty' });
    }

    // Calculate total
    const total_amount = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    // Create order
    const [orderResult] = await connection.query(
      'INSERT INTO orders (user_id, total_amount, payment_method, delivery_address, delivery_time) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, total_amount, payment_method, delivery_address, delivery_time]
    );

    const orderId = orderResult.insertId;

    // Insert order items
    for (const item of cartItems) {
      await connection.query(
        'INSERT INTO order_items (order_id, menu_item_id, quantity, price) VALUES (?, ?, ?, ?)',
        [orderId, item.menu_item_id, item.quantity, item.price]
      );
    }

    // Clear cart
    await connection.query('DELETE FROM cart WHERE user_id = ?', [req.user.id]);

    await connection.commit();

    res.status(201).json({
      success: true,
      message: 'Order placed successfully',
      order: { id: orderId, total_amount, status: 'pending' }
    });
  } catch (error) {
    if (connection) {
      await connection.rollback();
    }
    console.error('Create order error:', error);
    console.error('Error details:', {
      message: error.message,
      code: error.code,
      sqlMessage: error.sqlMessage
    });
    
    // Provide more specific error messages
    let errorMessage = 'Failed to create order';
    if (error.code === 'ER_NO_SUCH_TABLE') {
      errorMessage = 'Database table not found. Please ensure database is properly set up.';
    } else if (error.code === 'ER_DUP_ENTRY') {
      errorMessage = 'Duplicate order entry detected';
    } else if (error.code === 'ECONNREFUSED') {
      errorMessage = 'Database connection failed';
    } else if (error.sqlMessage) {
      errorMessage = `Database error: ${error.sqlMessage}`;
    }
    
    res.status(500).json({ success: false, message: errorMessage });
  } finally {
    if (connection) {
      connection.release();
    }
  }
};

// Get user's orders
exports.getUserOrders = async (req, res) => {
  try {
    const [orders] = await db.query(
      `SELECT o.*, 
       (SELECT JSON_ARRAYAGG(JSON_OBJECT('name', m.name, 'quantity', oi.quantity, 'price', oi.price))
        FROM order_items oi
        JOIN menu_items m ON oi.menu_item_id = m.id
        WHERE oi.order_id = o.id) as items
       FROM orders o
       WHERE o.user_id = ?
       ORDER BY o.created_at DESC`,
      [req.user.id]
    );

    res.json({ success: true, orders });
  } catch (error) {
    console.error('Get user orders error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Get order by ID
exports.getOrderById = async (req, res) => {
  try {
    const [orders] = await db.query(
      `SELECT o.*, 
       (SELECT JSON_ARRAYAGG(JSON_OBJECT('name', m.name, 'quantity', oi.quantity, 'price', oi.price, 'image_url', m.image_url))
        FROM order_items oi
        JOIN menu_items m ON oi.menu_item_id = m.id
        WHERE oi.order_id = o.id) as items
       FROM orders o
       WHERE o.id = ? AND o.user_id = ?`,
      [req.params.id, req.user.id]
    );

    if (orders.length === 0) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    res.json({ success: true, order: orders[0] });
  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Get all orders (Admin only)
exports.getAllOrders = async (req, res) => {
  try {
    const [orders] = await db.query(
      `SELECT o.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
       (SELECT JSON_ARRAYAGG(JSON_OBJECT('name', m.name, 'quantity', oi.quantity, 'price', oi.price))
        FROM order_items oi
        JOIN menu_items m ON oi.menu_item_id = m.id
        WHERE oi.order_id = o.id) as items
       FROM orders o
       JOIN users u ON o.user_id = u.id
       ORDER BY o.created_at DESC`
    );

    res.json({ success: true, orders });
  } catch (error) {
    console.error('Get all orders error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Update order status (Admin only)
exports.updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const [result] = await db.query(
      'UPDATE orders SET status = ? WHERE id = ?',
      [status, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    res.json({ success: true, message: 'Order status updated' });
  } catch (error) {
    console.error('Update order status error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};
