const db = require('../config/database');

// Get all menu items
exports.getAllMenuItems = async (req, res) => {
  try {
    // Try with in_stock filter first, fallback to all items if column doesn't exist
    let query = 'SELECT * FROM menu_items ORDER BY category, name';
    try {
      const [menuItems] = await db.query('SELECT * FROM menu_items WHERE in_stock = true ORDER BY category, name');
      res.json({ success: true, menuItems });
    } catch (err) {
      // If in_stock column doesn't exist, get all items
      if (err.code === 'ER_BAD_FIELD_ERROR') {
        const [menuItems] = await db.query(query);
        res.json({ success: true, menuItems });
      } else {
        throw err;
      }
    }
  } catch (error) {
    console.error('Get menu items error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Get menu item by ID
exports.getMenuItemById = async (req, res) => {
  try {
    const [menuItems] = await db.query('SELECT * FROM menu_items WHERE id = ?', [req.params.id]);
    
    if (menuItems.length === 0) {
      return res.status(404).json({ success: false, message: 'Menu item not found' });
    }

    res.json({ success: true, menuItem: menuItems[0] });
  } catch (error) {
    console.error('Get menu item error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Add new menu item (Admin only)
exports.addMenuItem = async (req, res) => {
  try {
    const { name, description, price, image_url, category, rating } = req.body;

    const [result] = await db.query(
      'INSERT INTO menu_items (name, description, price, image_url, category, rating) VALUES (?, ?, ?, ?, ?, ?)',
      [name, description, price, image_url, category, rating || 0]
    );

    res.status(201).json({
      success: true,
      message: 'Menu item added successfully',
      menuItem: { id: result.insertId, ...req.body }
    });
  } catch (error) {
    console.error('Add menu item error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Update menu item (Admin only)
exports.updateMenuItem = async (req, res) => {
  try {
    const { name, description, price, image_url, category, rating, in_stock } = req.body;

    const [result] = await db.query(
      'UPDATE menu_items SET name = ?, description = ?, price = ?, image_url = ?, category = ?, rating = ?, in_stock = ? WHERE id = ?',
      [name, description, price, image_url, category, rating, in_stock, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Menu item not found' });
    }

    res.json({ success: true, message: 'Menu item updated successfully' });
  } catch (error) {
    console.error('Update menu item error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Delete menu item (Admin only)
exports.deleteMenuItem = async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM menu_items WHERE id = ?', [req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Menu item not found' });
    }

    res.json({ success: true, message: 'Menu item deleted successfully' });
  } catch (error) {
    console.error('Delete menu item error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};
