const db = require('../config/database');

// Get user's cart
exports.getCart = async (req, res) => {
  try {
    const [cartItems] = await db.query(
      `SELECT c.id, c.quantity, m.id as menu_item_id, m.name, m.description, m.price, m.image_url, m.category
       FROM cart c
       JOIN menu_items m ON c.menu_item_id = m.id
       WHERE c.user_id = ?`,
      [req.user.id]
    );

    const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    res.json({ success: true, cartItems, total });
  } catch (error) {
    console.error('Get cart error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Add item to cart
exports.addToCart = async (req, res) => {
  try {
    const { menu_item_id, quantity } = req.body;

    // Check if item already in cart
    const [existing] = await db.query(
      'SELECT * FROM cart WHERE user_id = ? AND menu_item_id = ?',
      [req.user.id, menu_item_id]
    );

    if (existing.length > 0) {
      // Update quantity
      await db.query(
        'UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND menu_item_id = ?',
        [quantity || 1, req.user.id, menu_item_id]
      );
    } else {
      // Insert new cart item
      await db.query(
        'INSERT INTO cart (user_id, menu_item_id, quantity) VALUES (?, ?, ?)',
        [req.user.id, menu_item_id, quantity || 1]
      );
    }

    res.json({ success: true, message: 'Item added to cart' });
  } catch (error) {
    console.error('Add to cart error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Update cart item quantity
exports.updateCartItem = async (req, res) => {
  try {
    const { quantity } = req.body;

    if (quantity <= 0) {
      // Remove item if quantity is 0 or less
      await db.query('DELETE FROM cart WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    } else {
      await db.query(
        'UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?',
        [quantity, req.params.id, req.user.id]
      );
    }

    res.json({ success: true, message: 'Cart updated' });
  } catch (error) {
    console.error('Update cart error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Remove item from cart
exports.removeFromCart = async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM cart WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Cart item not found' });
    }

    res.json({ success: true, message: 'Item removed from cart' });
  } catch (error) {
    console.error('Remove from cart error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Clear entire cart
exports.clearCart = async (req, res) => {
  try {
    await db.query('DELETE FROM cart WHERE user_id = ?', [req.user.id]);
    res.json({ success: true, message: 'Cart cleared' });
  } catch (error) {
    console.error('Clear cart error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};
