const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const port = process.env.PORT || 3000;

// Set the view engine to ejs
app.set('view engine', 'ejs');

// Middleware to parse JSON and urlencoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve static files from the src directory
app.use(express.static(path.join(__dirname, 'src')));

// Serve static files from the src/assets directory
app.use('/src/assets', express.static(path.join(__dirname, 'src/assets')));

// Serve static files from the src directory with /src prefix
app.use('/src', express.static(path.join(__dirname, 'src')));

// Serve static files from the src/styles directory
app.use('/styles', express.static(path.join(__dirname, 'src/styles')));

// Serve static files from the src/js directory
app.use('/js', express.static(path.join(__dirname, 'src/js')));

// Serve static files from the src/pages directory
app.use('/pages', express.static(path.join(__dirname, 'src/pages')));

// Serve static files from the src/components directory
app.use('/components', express.static(path.join(__dirname, 'src/components')));

// Special handling for CSS files
app.get('*.css', (req, res, next) => {
  const filePath = path.join(__dirname, req.path);
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    next();
  }
});

// API Proxy
app.use('/api', (req, res) => {
  // This will be handled by your backend
  res.status(200).json({ message: 'API endpoint' });
});

// Route for login page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/pages/login.html'));
});

// Route for menu page
app.get('/menu', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/pages/menu.html'));
});

// Route for cart page
app.get('/cart', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/pages/cart.html'));
});

// Route for orders page
app.get('/orders', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/pages/orders.html'));
});

// Serve index.html for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`Frontend server running on http://localhost:${port}`);
  console.log(`Serving static files from: ${__dirname}`);
});
