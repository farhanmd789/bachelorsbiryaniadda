// Import required functions
import { API_URL, getAuthToken, getUserData, logout as apiLogout } from './config.js';

// Initialize user authentication state
document.addEventListener('DOMContentLoaded', () => {
    updateAuthUI();
    
    // Delegate click events for dynamic elements
    document.addEventListener('click', (e) => {
        // Handle logout button click
        if (e.target.closest && e.target.closest('#logout-btn')) {
            e.preventDefault();
            logoutUser();
        }
        // Toggle user dropdown
        else if (e.target.closest && e.target.closest('.user-profile-btn')) {
            e.preventDefault();
            const dropdown = document.querySelector('.dropdown-menu');
            if (dropdown) {
                dropdown.classList.toggle('show');
            }
        }
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        const dropdown = document.querySelector('.dropdown-menu');
        const profileBtn = document.querySelector('.user-profile-btn');
        
        if (dropdown && !dropdown.contains(e.target) && 
            profileBtn && !profileBtn.contains(e.target)) {
            dropdown.classList.remove('show');
        }
    });
});

// Update the UI based on authentication state
function updateAuthUI() {
    console.log('🔄 Updating auth UI...');
    
    const user = getUserData();
    const token = getAuthToken();
    const authButtons = document.getElementById('auth-buttons');
    
    console.log('👤 User:', user);
    console.log('🔑 Token:', token ? 'Present' : 'Missing');
    console.log('📍 Auth buttons element:', authButtons ? 'Found' : 'Not found');
    
    if (!authButtons) {
        console.warn('⚠️ Auth buttons container not found');
        return;
    }

    if (user && token) {
        // User is logged in
        console.log('✅ User is logged in, showing user dropdown');
        const userName = user.name || 'My Account';
        const userInitial = userName.charAt(0).toUpperCase();
        const userEmail = user.email || '';
        
        authButtons.innerHTML = `
            <div class="user-dropdown">
                <button class="user-profile-btn" aria-expanded="false" aria-haspopup="true">
                    <div class="user-avatar" aria-hidden="true">${userInitial}</div>
                    <span class="user-name-display">${userName}</span>
                    <i class="ri-arrow-down-s-line" aria-hidden="true"></i>
                </button>
                <div class="dropdown-menu" role="menu">
                    <div class="dropdown-header">
                        <p class="user-name">${userName}</p>
                        ${userEmail ? `<p class="user-email">${userEmail}</p>` : ''}
                    </div>
                    <a href="/pages/orders.html" class="dropdown-item" role="menuitem">
                        <i class="ri-shopping-bag-line" aria-hidden="true"></i> My Orders
                    </a>
                    <a href="/pages/profile.html" class="dropdown-item" role="menuitem">
                        <i class="ri-user-settings-line" aria-hidden="true"></i> Profile Settings
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" id="logout-btn" class="dropdown-item" role="menuitem">
                        <i class="ri-logout-box-line" aria-hidden="true"></i> Logout
                    </a>
                </div>
            </div>
        `;
        
        // Update cart count if available
        updateCartCount();

        // Add click handler for dropdown toggle
        const profileBtn = document.querySelector('.user-profile-btn');
        if (profileBtn) {
            profileBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                document.querySelector('.dropdown-menu').classList.toggle('show');
            });
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            const dropdown = document.querySelector('.dropdown-menu');
            if (dropdown && !dropdown.contains(e.target) && !e.target.closest('.user-profile-btn')) {
                dropdown.classList.remove('show');
            }
        });
    } else {
        // User is not logged in
        console.log('ℹ️ User is not logged in, showing login button');
        authButtons.innerHTML = `
            <a href="/pages/login.html" class="auth-btn">
                <i class="ri-user-fill"></i>
                <span>Login/Register</span>
            </a>
        `;
    }
    
    console.log('✅ Auth UI updated successfully');
}

// Logout the user
async function logoutUser() {
    try {
        // Call logout API if user is authenticated
        const token = getAuthToken();
        if (token) {
            try {
                await fetch(`${API_URL}/auth/logout`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });
            } catch (error) {
                console.error('Logout API error:', error);
                // Continue with client-side logout even if API call fails
            }
        }
        
        // Clear user data from localStorage
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        
        // Update UI
        updateAuthUI();
        
        // Show a brief message before redirecting
        const currentPath = window.location.pathname;
        const isAuthPage = currentPath.includes('login.html') || 
                          currentPath.includes('register.html');
        
        if (!isAuthPage) {
            // Show a brief message before redirecting
            const message = document.createElement('div');
            message.className = 'logout-message';
            message.textContent = 'Logging out...';
            document.body.appendChild(message);
            
            // Redirect to home page after a short delay
            setTimeout(() => {
                window.location.href = '/';
            }, 1000);
        }
    } catch (error) {
        console.error('Logout error:', error);
        // Force redirect even if there's an error
        window.location.href = '/';
    }
}

// Helper function to update cart count in the header
function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        const cart = JSON.parse(localStorage.getItem('cart') || '[]');
        const count = cart.reduce((total, item) => total + (item.quantity || 1), 0);
        cartCount.textContent = count > 0 ? count : '';
        cartCount.style.display = count > 0 ? 'flex' : 'none';
    }
}

// Export functions for use in other modules
export { updateAuthUI, logoutUser, updateCartCount };
