// Cart elements
const cartItemsList = document.getElementById('cart-items-list');
const subtotalEl = document.getElementById('subtotal');
const deliveryFeeEl = document.getElementById('delivery-fee');
const taxEl = document.getElementById('tax');
const totalEl = document.getElementById('total');
const checkoutBtn = document.getElementById('checkout-btn');
const checkoutModal = document.getElementById('checkout-modal');
const checkoutForm = document.getElementById('checkout-form');
const cancelCheckoutBtn = document.getElementById('cancel-checkout');
const paymentModal = document.getElementById('payment-modal');
const paymentForm = document.getElementById('payment-form');
const cancelPaymentBtn = document.getElementById('cancel-payment');
const cardTab = document.getElementById('card-tab');
const upiTab = document.getElementById('upi-tab');
const cardPayment = document.getElementById('card-payment');
const upiPayment = document.getElementById('upi-payment');
const paymentTotalEl = document.getElementById('payment-total');

// Constants
const DELIVERY_FEE = 40;

// Cart state
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Import API configuration
import { API_URL, isLoggedIn, getAuthToken } from './config.js';

// Initialize the page
document.addEventListener('DOMContentLoaded', async () => {
  try {
    if (isLoggedIn()) {
      // Load cart from database for logged-in users
      await loadCartFromDatabase();
    } else {
      // Load cart from localStorage for guest users
      if (cart.length > 0) {
        displayCartItems(cart);
        updateSummary();
      } else {
        showEmptyCart();
      }
    }
    
    // Update cart count in the header
    updateCartCount();
    
    // Setup event listeners
    setupEventListeners();
  } catch (error) {
    console.error('Error initializing cart:', error);
    showNotification('Error loading cart. Please try again.', 'error');
  }
});

// Load cart from database
async function loadCartFromDatabase() {
  try {
    const data = await apiCall('/cart');
    
    if (data.success && data.cartItems.length > 0) {
      // Convert database format to local cart format
      cart = data.cartItems.map(item => ({
        id: item.menu_item_id,
        name: item.name,
        description: item.description,
        price: item.price,
        image_url: item.image_url,
        quantity: item.quantity,
        cart_id: item.id // Store cart ID for updates/deletes
      }));
      
      displayCartItems(cart);
      updateSummary();
    } else {
      showEmptyCart();
    }
  } catch (error) {
    console.error('Failed to load cart:', error);
    // Fallback to localStorage
    if (cart.length > 0) {
      displayCartItems(cart);
      updateSummary();
    } else {
      showEmptyCart();
    }
  }
}

// Set up event listeners
function setupEventListeners() {
  // Checkout button
  if (checkoutBtn) {
    checkoutBtn.addEventListener('click', handleCheckout);
  }
  
  // Cancel checkout button
  if (cancelCheckoutBtn) {
    cancelCheckoutBtn.addEventListener('click', () => {
      if (checkoutModal) {
        checkoutModal.style.display = 'none';
      }
    });
  }
  
  // Checkout form submission
  if (checkoutForm) {
    checkoutForm.addEventListener('submit', handleCheckoutSubmit);
  }
  
  // Payment modal handlers
  if (cancelPaymentBtn) {
    cancelPaymentBtn.addEventListener('click', () => {
      if (paymentModal) paymentModal.style.display = 'none';
      if (checkoutModal) checkoutModal.style.display = 'flex';
    });
  }
  
  if (paymentForm) {
    paymentForm.addEventListener('submit', handlePaymentSubmit);
  }
  
  // Payment tab switching
  if (cardTab) {
    cardTab.addEventListener('click', () => switchPaymentTab('card'));
  }
  
  if (upiTab) {
    upiTab.addEventListener('click', () => switchPaymentTab('upi'));
  }
  
  // Card number formatting
  const cardNumberInput = document.getElementById('card-number');
  if (cardNumberInput) {
    cardNumberInput.addEventListener('input', formatCardNumber);
  }
  
  // Expiry date formatting
  const cardExpiryInput = document.getElementById('card-expiry');
  if (cardExpiryInput) {
    cardExpiryInput.addEventListener('input', formatExpiryDate);
  }
  
  // CVV validation
  const cardCvvInput = document.getElementById('card-cvv');
  if (cardCvvInput) {
    cardCvvInput.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/\D/g, '');
    });
  }
  
  // Set minimum delivery time to current time
  setMinimumDeliveryTime();
  
  // Event delegation for dynamically created cart item buttons
  if (cartItemsList) {
    cartItemsList.addEventListener('click', async (e) => {
      // Handle quantity buttons
      if (e.target.classList.contains('quantity-btn') || e.target.parentElement.classList.contains('quantity-btn')) {
        const btn = e.target.classList.contains('quantity-btn') ? e.target : e.target.parentElement;
        const action = btn.dataset.action;
        const itemId = parseInt(btn.dataset.id);
        
        const item = cart.find(item => item.id === itemId);
        if (item) {
          const newQuantity = action === 'increase' ? item.quantity + 1 : item.quantity - 1;
          if (newQuantity > 0) {
            await updateQuantity(itemId, newQuantity);
          }
        }
      }
      
      // Handle remove button
      if (e.target.classList.contains('remove-item') || e.target.parentElement.classList.contains('remove-item')) {
        const btn = e.target.classList.contains('remove-item') ? e.target : e.target.parentElement;
        const itemId = parseInt(btn.dataset.id);
        await removeFromCart(itemId);
      }
    });
  }
}

// Display cart items
function displayCartItems(items) {
  if (!cartItemsList) return;
  
  try {
    // Clear the cart items list
    cartItemsList.innerHTML = '';
    
    if (!items || items.length === 0) {
      showEmptyCart();
      return;
    }
    
    // Render each cart item
    items.forEach((item, index) => {
      const itemElement = document.createElement('div');
      itemElement.className = 'cart-item';
      itemElement.dataset.id = item.id || `item-${index}`;
      
      // Format image path - handle different image formats
      let imagePath = '/src/assets/images/default-dish.jpg';
      
      if (item.image_url) {
        if (item.image_url.startsWith('http')) {
          imagePath = item.image_url;
        } else if (item.image_url.startsWith('images/')) {
          imagePath = `/src/assets/${item.image_url}`;
        } else if (item.image_url.startsWith('/')) {
          imagePath = item.image_url;
        } else {
          imagePath = `/src/assets/images/${item.image_url}`;
        }
      }
      
      itemElement.innerHTML = `
        <div class="item-image">
          <img src="${imagePath}" alt="${item.name}" onerror="this.onerror=null;this.src='/src/assets/images/default-dish.jpg'" />
        </div>
        <div class="item-details">
          <h3>${item.name}</h3>
          <p class="item-description">${item.description || 'Delicious dish'}</p>
          <div class="item-price">₹${(item.price || 0).toFixed(2)}</div>
        </div>
        <div class="item-quantity">
          <button class="quantity-btn" data-action="decrease" data-id="${item.id || index}" aria-label="Decrease quantity">-</button>
          <span>${item.quantity || 1}</span>
          <button class="quantity-btn" data-action="increase" data-id="${item.id || index}" aria-label="Increase quantity">+</button>
        </div>
        <div class="item-total">₹${((item.price || 0) * (item.quantity || 1)).toFixed(2)}</div>
        <button class="remove-item" data-id="${item.id || index}" aria-label="Remove item">
          <i class="ri-delete-bin-line"></i>
        </button>
      `;
      
      cartItemsList.appendChild(itemElement);
    });
    
    // Show cart items and hide empty message
    cartItemsList.style.display = 'block';
    const emptyCartEl = document.querySelector('.empty-cart');
    if (emptyCartEl) {
      emptyCartEl.style.display = 'none';
    }
    
    // Update summary and cart count
    updateSummary();
    updateCartCount();
    
  } catch (error) {
    console.error('Error displaying cart items:', error);
    showNotification('Error displaying cart items', 'error');
    showEmptyCart();
  }
}

// Show empty cart
function showEmptyCart() {
  const emptyCartEl = document.querySelector('.empty-cart');
  
  if (emptyCartEl) {
    emptyCartEl.style.display = 'flex';
  }
  
  if (cartItemsList) {
    cartItemsList.innerHTML = '';
  }
  
  // Update summary with zeros
  if (subtotalEl) subtotalEl.textContent = '₹0';
  if (deliveryFeeEl) deliveryFeeEl.textContent = '₹0';
  if (taxEl) taxEl.textContent = '₹0';
  if (totalEl) totalEl.textContent = '₹0';
  
  // Disable checkout button
  if (checkoutBtn) checkoutBtn.disabled = true;
  
  // Update cart count in the header
  updateCartCount();
}

// Update summary
function updateSummary() {
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const delivery = cart.length > 0 ? DELIVERY_FEE : 0;
  const tax = subtotal * 0.05; // 5% tax
  const total = subtotal + delivery + tax;
  
  if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toFixed(2)}`;
  if (deliveryFeeEl) deliveryFeeEl.textContent = `₹${delivery.toFixed(2)}`;
  if (taxEl) taxEl.textContent = `₹${tax.toFixed(2)}`;
  if (totalEl) totalEl.textContent = `₹${total.toFixed(2)}`;
  
  // Save cart to localStorage
  localStorage.setItem('cart', JSON.stringify(cart));
  
  // Update cart count in the header
  updateCartCount();
}

// Update quantity
async function updateQuantity(itemId, newQuantity) {
  if (newQuantity < 1) return;
  
  const itemIndex = cart.findIndex(item => item.id === itemId);
  
  if (itemIndex !== -1) {
    if (isLoggedIn()) {
      // Update in database
      try {
        const cartId = cart[itemIndex].cart_id;
        await apiCall(`/cart/${cartId}`, {
          method: 'PUT',
          body: JSON.stringify({ quantity: newQuantity })
        });
      } catch (error) {
        console.error('Failed to update cart in database:', error);
      }
    }
    
    cart[itemIndex].quantity = newQuantity;
    
    // If quantity is 0, remove the item
    if (newQuantity === 0) {
      cart.splice(itemIndex, 1);
    }
    
    // Update the display
    if (cart.length === 0) {
      showEmptyCart();
    } else {
      displayCartItems(cart);
    }
    
    // Update the summary
    updateSummary(cart);
    
    // Save cart to local storage (for guest users)
    if (!isLoggedIn()) {
      localStorage.setItem('cart', JSON.stringify(cart));
    }
  }
}

// Remove from cart
async function removeFromCart(itemId) {
  const itemIndex = cart.findIndex(item => item.id === itemId);
  
  if (itemIndex !== -1) {
    if (isLoggedIn()) {
      // Remove from database
      try {
        const cartId = cart[itemIndex].cart_id;
        await apiCall(`/cart/${cartId}`, {
          method: 'DELETE'
        });
      } catch (error) {
        console.error('Failed to remove from database:', error);
      }
    }
    
    cart.splice(itemIndex, 1);
    
    // Update the display
    if (cart.length === 0) {
      showEmptyCart();
    } else {
      displayCartItems(cart);
    }
    
    // Update the summary
    updateSummary(cart);
    
    // Show notification
    showNotification('Item removed from cart');
    
    // Save cart to local storage (for guest users)
    if (!isLoggedIn()) {
      localStorage.setItem('cart', JSON.stringify(cart));
    }
  }
}

// Update cart count in the header and other places
function updateCartCount() {
  try {
    // Calculate total items in cart
    const count = cart.reduce((total, item) => total + (item.quantity || 1), 0);
    
    // Update cart count in the header (desktop and mobile)
    const cartCountElements = document.querySelectorAll('#cart-count, .cart-count');
    cartCountElements.forEach(element => {
      if (element) {
        element.textContent = count > 0 ? count : '';
        element.style.display = count > 0 ? 'flex' : 'none';
      }
    });
    
    // Update cart count in the mobile menu
    const mobileCartCount = document.querySelector('.mobile-cart-count');
    if (mobileCartCount) {
      mobileCartCount.textContent = count > 0 ? count : '';
      mobileCartCount.style.display = count > 0 ? 'flex' : 'none';
    }
    
    // Update cart count in the mobile menu button if it exists
    const mobileMenuCartCount = document.querySelector('.mobile-menu-cart-count');
    if (mobileMenuCartCount) {
      mobileMenuCartCount.textContent = count > 0 ? count : '';
      mobileMenuCartCount.style.display = count > 0 ? 'flex' : 'none';
    }
    
    // Update the cart count in the browser tab title if there are items
    if (count > 0) {
      document.title = `(${count}) ${document.title.replace(/^\(\d+\)\s*/, '')}`;
    } else {
      document.title = document.title.replace(/^\(\d+\)\s*/, '');
    }
    
    return count;
  } catch (error) {
    console.error('Error updating cart count:', error);
    return 0;
  }
}

// Set minimum delivery time to prevent past dates
function setMinimumDeliveryTime() {
  const deliveryTimeInput = document.getElementById('delivery-time');
  if (deliveryTimeInput) {
    // Get current date and time
    const now = new Date();
    // Add 30 minutes buffer for preparation
    now.setMinutes(now.getMinutes() + 30);
    
    // Format to datetime-local input format (YYYY-MM-DDTHH:MM)
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    const minDateTime = `${year}-${month}-${day}T${hours}:${minutes}`;
    deliveryTimeInput.min = minDateTime;
    
    // Set default value to minimum time if empty
    if (!deliveryTimeInput.value) {
      deliveryTimeInput.value = minDateTime;
    }
  }
}

// Handle checkout
function handleCheckout() {
  console.log('Checkout clicked, cart items:', cart.length);
  
  if (!cart || cart.length === 0) {
    alert('Your cart is empty. Please add items before checkout.');
    return;
  }
  
  if (checkoutModal) {
    checkoutModal.style.display = 'flex';
    // Set minimum delivery time when modal opens
    setMinimumDeliveryTime();
  } else {
    console.error('Checkout modal not found');
  }
}

// Store order details temporarily
let orderDetails = null;

// Handle checkout form submission
async function handleCheckoutSubmit(e) {
  e.preventDefault();
  
  const deliveryAddress = document.getElementById('delivery-address').value;
  const deliveryTime = document.getElementById('delivery-time').value;
  const paymentMethod = document.getElementById('payment-method').value;
  
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.05;
  const total = subtotal + DELIVERY_FEE + tax;
  
  // Store order details
  orderDetails = {
    deliveryAddress,
    deliveryTime,
    paymentMethod,
    subtotal,
    tax,
    total
  };
  
  // If online payment, show payment modal
  if (paymentMethod === 'online') {
    if (checkoutModal) checkoutModal.style.display = 'none';
    if (paymentModal) {
      paymentModal.style.display = 'flex';
      if (paymentTotalEl) paymentTotalEl.textContent = `₹${total.toFixed(2)}`;
    }
    return;
  }
  
  // If cash on delivery, proceed with order
  await placeOrder();
}

// Handle payment form submission
async function handlePaymentSubmit(e) {
  e.preventDefault();
  
  const activeTab = document.querySelector('.payment-tab.active');
  const paymentType = activeTab ? activeTab.id.replace('-tab', '') : 'card';
  
  // Validate payment details
  if (paymentType === 'card') {
    const cardNumber = document.getElementById('card-number').value;
    const cardName = document.getElementById('card-name').value;
    const cardExpiry = document.getElementById('card-expiry').value;
    const cardCvv = document.getElementById('card-cvv').value;
    
    if (!cardNumber || !cardName || !cardExpiry || !cardCvv) {
      showNotification('Please fill in all card details');
      return;
    }
    
    if (cardNumber.replace(/\s/g, '').length < 13) {
      showNotification('Please enter a valid card number');
      return;
    }
    
    if (cardCvv.length < 3) {
      showNotification('Please enter a valid CVV');
      return;
    }
  } else if (paymentType === 'upi') {
    const upiId = document.getElementById('upi-id').value;
    
    if (!upiId) {
      showNotification('Please enter your UPI ID');
      return;
    }
  }
  
  // Process payment and place order
  await placeOrder();
}

// Place order function
async function placeOrder() {
  console.log('placeOrder called');
  console.log('orderDetails:', orderDetails);
  console.log('cart:', cart);
  
  if (!orderDetails) {
    alert('Order details are missing. Please try again.');
    return;
  }
  
  // Validate cart has items
  if (!cart || cart.length === 0) {
    alert('Your cart is empty. Please add items before placing an order.');
    return;
  }
  
  // Check if user is logged in
  const userLoggedIn = typeof isLoggedIn === 'function' ? isLoggedIn() : false;
  console.log('User logged in:', userLoggedIn);
  
  if (userLoggedIn) {
    // Create order in database for logged-in users
    try {
      console.log('Sending order to backend...');
      const data = await apiCall('/orders', {
        method: 'POST',
        body: JSON.stringify({
          payment_method: orderDetails.paymentMethod,
          delivery_address: orderDetails.deliveryAddress,
          delivery_time: orderDetails.deliveryTime
        })
      });
      
      console.log('Backend response:', data);
      
      if (data.success) {
        console.log('Order placed successfully!');
        
        // Clear local cart
        cart = [];
        localStorage.setItem('cart', JSON.stringify(cart));
        
        // Hide modals
        if (checkoutModal) checkoutModal.style.display = 'none';
        if (paymentModal) paymentModal.style.display = 'none';
        
        // Show success message with better styling
        showSuccessMessage();
        
        // Update cart count
        updateCartCount();
        
        // Redirect to orders page after delay
        setTimeout(() => {
          window.location.href = 'orders.html';
        }, 2500);
      } else {
        console.error('Order failed:', data.message);
        alert('Failed to place order: ' + (data.message || 'Unknown error'));
      }
    } catch (error) {
      console.error('Order creation failed:', error);
      alert('Failed to place order: ' + error.message + '\nPlease check if the server is running.');
    }
  } else {
    // Save order to localStorage for guest users
    console.log('Processing guest user order');
    try {
      const orderData = {
        items: cart,
        deliveryAddress: orderDetails.deliveryAddress,
        deliveryTime: orderDetails.deliveryTime,
        paymentMethod: orderDetails.paymentMethod,
        subtotal: orderDetails.subtotal,
        deliveryFee: DELIVERY_FEE,
        tax: orderDetails.tax,
        total: orderDetails.total
      };
      
      console.log('Order data:', orderData);
      
      const orders = JSON.parse(localStorage.getItem('orders')) || [];
      orders.push({
        ...orderData,
        id: Date.now(),
        date: new Date().toISOString(),
        status: 'pending'
      });
      localStorage.setItem('orders', JSON.stringify(orders));
      console.log('Order saved to localStorage');
      
      // Clear cart
      cart = [];
      localStorage.setItem('cart', JSON.stringify(cart));
      
      // Hide modals
      if (checkoutModal) checkoutModal.style.display = 'none';
      if (paymentModal) paymentModal.style.display = 'none';
      
      // Show success message
      showSuccessMessage();
      
      // Update cart count
      updateCartCount();
      
      // Redirect to orders page after delay
      setTimeout(() => {
        window.location.href = 'orders.html';
      }, 2500);
    } catch (error) {
      console.error('Failed to save order:', error);
      alert('Failed to place order: ' + error.message);
    }
  }
}

// Switch payment tab
function switchPaymentTab(tab) {
  const tabs = document.querySelectorAll('.payment-tab');
  tabs.forEach(t => {
    t.classList.remove('active');
    t.style.borderBottom = '3px solid transparent';
    t.style.color = 'var(--text-light)';
  });
  
  if (tab === 'card') {
    if (cardTab) {
      cardTab.classList.add('active');
      cardTab.style.borderBottom = '3px solid var(--primary-color)';
      cardTab.style.color = 'var(--primary-color)';
    }
    if (cardPayment) cardPayment.style.display = 'block';
    if (upiPayment) upiPayment.style.display = 'none';
  } else {
    if (upiTab) {
      upiTab.classList.add('active');
      upiTab.style.borderBottom = '3px solid var(--primary-color)';
      upiTab.style.color = 'var(--primary-color)';
    }
    if (cardPayment) cardPayment.style.display = 'none';
    if (upiPayment) upiPayment.style.display = 'block';
  }
}

// Format card number with spaces
function formatCardNumber(e) {
  let value = e.target.value.replace(/\s/g, '');
  value = value.replace(/\D/g, '');
  
  let formattedValue = '';
  for (let i = 0; i < value.length; i++) {
    if (i > 0 && i % 4 === 0) {
      formattedValue += ' ';
    }
    formattedValue += value[i];
  }
  
  e.target.value = formattedValue;
}

// Format expiry date as MM/YY
function formatExpiryDate(e) {
  let value = e.target.value.replace(/\D/g, '');
  
  if (value.length >= 2) {
    value = value.substring(0, 2) + '/' + value.substring(2, 4);
  }
  
  e.target.value = value;
}

// Show success message
function showSuccessMessage() {
  // Create success modal
  const successModal = document.createElement('div');
  successModal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 10001;
    display: flex;
    align-items: center;
    justify-content: center;
  `;
  
  successModal.innerHTML = `
    <div style="background: white; padding: 3rem; border-radius: 15px; text-align: center; max-width: 400px; animation: slideIn 0.3s ease-out;">
      <div style="width: 80px; height: 80px; background: #10b981; border-radius: 50%; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center;">
        <i class="ri-check-line" style="font-size: 3rem; color: white;"></i>
      </div>
      <h2 style="color: var(--text-dark); margin-bottom: 1rem; font-size: 1.8rem;">Order Placed Successfully!</h2>
      <p style="color: var(--text-light); margin-bottom: 1.5rem;">Thank you for your order. You will be redirected to your orders page.</p>
      <div style="display: flex; align-items: center; justify-content: center; gap: 0.5rem; color: var(--primary-color);">
        <div class="spinner" style="width: 20px; height: 20px; border: 3px solid #f3f4f6; border-top-color: var(--primary-color); border-radius: 50%; animation: spin 1s linear infinite;"></div>
        <span>Redirecting...</span>
      </div>
    </div>
  `;
  
  // Add animations
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateY(-50px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(successModal);
}

// Show notification
function showNotification(message) {
  // Create notification element if it doesn't exist
  let notification = document.querySelector('.notification');
  
  if (!notification) {
    notification = document.createElement('div');
    notification.className = 'notification';
    document.body.appendChild(notification);
  }
  
  // Set message and show notification
  notification.textContent = message;
  notification.classList.add('show');
  
  // Hide after 3 seconds
  setTimeout(() => {
    notification.classList.remove('show');
  }, 3000);
}

