// Import API configuration
import { API_URL, isLoggedIn, apiCall, getUserData, logout } from './config.js';

// Menu items data - This would typically come from your backend
const menuItems = [
  {
    id: 1,
    name: 'Chicken Biryani',
    description: 'Fragrant basmati rice cooked with tender chicken pieces and aromatic spices',
    price: 250,
    image_url: '/src/assets/images/biryani.png',
    category: 'biryani',
    rating: 4.5
  },
  {
    id: 2,
    name: 'Paneer Biryani',
    description: 'Aromatic basmati rice layered with marinated paneer cubes and fresh vegetables. A perfect vegetarian delight with rich flavors.',
    price: 249,
    image_url: '/src/assets/images/paneerbiryani.png',
    category: 'biryani',
    rating: 4.0
  },
  {
    id: 3,
    name: 'Mutton Biryani',
    description: 'Premium mutton pieces slow-cooked with aromatic basmati rice, saffron, and authentic Hyderabadi spices. Garnished with fried onions.',
    price: 379,
    image_url: '/src/assets/images/muttonbiryani.png',
    category: 'biryani',
    rating: 5.0
  },
  {
    id: 4,
    name: 'Apollo Fish',
    description: 'Crispy fried fish tossed in spicy tangy sauce with curry leaves, onions, and chilies. A popular Indo-Chinese fusion appetizer!',
    price: 299,
    image_url: '/src/assets/images/apollofish.jpg',
    category: 'starter',
    rating: 5.0
  },
  {
    id: 5,
    name: 'Butter Naan',
    description: 'Soft and buttery tandoor-baked flatbread',
    price: 30,
    image_url: '/src/assets/images/butternaanwhitebg.jpg',
    category: 'bread',
    rating: 4.5
  },
  {
    id: 6,
    name: 'Egg Biryani',
    description: 'Flavorful biryani with boiled eggs, aromatic spices and basmati rice. Perfect bachelor meal!',
    price: 180,
    image_url: '/src/assets/images/eggbiryaniwhitebg.jpg',
    category: 'biryani',
    rating: 4.3
  },
  {
    id: 7,
    name: 'Chicken Tikka Wrap',
    description: 'Soft tortilla wrap filled with grilled chicken tikka, fresh lettuce, onions, and tangy sauce. Perfect on-the-go meal!',
    price: 189,
    image_url: '../IMAGES/bachelorshawarma.png',
    category: 'starter',
    rating: 4.0
  },
  {
    id: 8,
    name: 'Veg Biryani',
    description: 'Delicious biryani made with fresh vegetables and aromatic spices',
    price: 180,
    image_url: '/src/assets/images/biryani.png',
    category: 'biryani',
    rating: 4.0
  },
  {
    id: 9,
    name: 'Chicken kabab',
    description: 'Diced chicken simmered in aromatic are flavorful and succulent pieces of chicken that are grilled over a charcoal',
    price: 279,
    image_url: '/src/assets/images/chicken65.jpg',
    category: 'starter',
    rating: 5.0
  },
  {
    id: 10,
    name: 'Mutton pepper-Fry',
    description: 'Mutton Pepper Fry is a spicy and flavorful preparation made with succulent mutton pieces, marinated in a blend.',
    price: 329,
    image_url: '/src/assets/images/mutton-pepper-fry.png',
    category: 'starter',
    rating: 5.0
  },
  {
    id: 11,
    name: 'Prawns biryani',
    description: 'Prawns biryani is a savory rice dish that\'s infused with spicy marinated prawns,layered with fragrant basmati rice.',
    price: 269,
    image_url: '/src/assets/images/veg-biryani.jpg',
    category: 'biryani',
    rating: 5.0
  }
];

// DOM Elements
const menuGrid = document.getElementById('menu-grid');
const categoryBtns = document.querySelectorAll('.category-btn');
const cartCount = document.getElementById('cart-count');

// Cart state
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Initialize the page
document.addEventListener('DOMContentLoaded', async () => {
  // Try to load menu from database, fallback to hardcoded items
  await loadMenuItems();
  updateCartCount();
  setupEventListeners();
  updateUserInfo();
  setupLogout();
});

// Load menu items from database or use hardcoded
async function loadMenuItems() {
  const loadingEl = document.getElementById('loading');
  
  try {
    const response = await fetch(`${API_URL}/menu`);
    const data = await response.json();
    
    if (data.success && data.menuItems && data.menuItems.length > 0) {
      // Use database menu items
      menuItems.length = 0; // Clear hardcoded items
      menuItems.push(...data.menuItems);
    }
  } catch (error) {
    console.log('Using hardcoded menu items (database not available)');
  }
  
  // Hide loading text
  if (loadingEl) {
    loadingEl.style.display = 'none';
  }
  
  // Display menu items (either from database or hardcoded)
  displayMenuItems(menuItems);
}

// Set up event listeners
function setupEventListeners() {
  // Category filter buttons
  categoryBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Update active button
      categoryBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      // Filter menu items
      const category = btn.dataset.category;
      const filteredItems = category === 'all' 
        ? menuItems 
        : menuItems.filter(item => item.category === category);
      
      displayMenuItems(filteredItems);
    });
  });
}

// Display menu items
function displayMenuItems(items) {
  if (!menuGrid) return;
  
  menuGrid.innerHTML = items.map(item => {
    // Format image path - handle different image formats
    let imagePath = '/src/assets/images/default-dish.jpg';
    
    if (item.image_url) {
      if (item.image_url.startsWith('http')) {
        imagePath = item.image_url;
      } else if (item.image_url.startsWith('images/')) {
        imagePath = `/src/assets/${item.image_url}`;
      } else if (item.image_url.startsWith('/')) {
        imagePath = item.image_url;
      } else {
        imagePath = `/src/assets/images/${item.image_url}`;
      }
    }
    
    return `
      <div class="menu-card" data-category="${item.category}">
        <img src="${imagePath}" alt="${item.name}" onerror="this.onerror=null;this.src='/src/assets/images/default-dish.jpg'">
        <div class="menu-card-content">
          <h3>${item.name}</h3>
          <p>${item.description}</p>
          <div class="menu-card-footer">
            <span class="price">₹${item.price}</span>
            <button class="btn add-to-cart" data-id="${item.id}">Add to Cart</button>
          </div>
        </div>
      </div>
    `;
  }).join('');
  
  // Add event listeners to the Add to Cart buttons
  document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', (e) => {
      const itemId = parseInt(e.target.dataset.id);
      addToCart(itemId);
    });
  });
}

// Add item to cart
async function addToCart(itemId) {
  const item = menuItems.find(item => item.id === itemId);
  if (!item) {
    showNotification('Item not found');
    return;
  }
  
  // Check if user is logged in
  const userLoggedIn = isLoggedIn();
  
  if (!userLoggedIn) {
    // Use localStorage for guest users
    const existingItem = cart.find(cartItem => cartItem.id === itemId);
    
    if (existingItem) {
      existingItem.quantity = (existingItem.quantity || 1) + 1;
    } else {
      cart.push({ ...item, quantity: 1 });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    showNotification(`${item.name} added to cart!`);
  } else {
    // Use database for logged-in users
    try {
      const data = await apiCall('/cart/add', {
        method: 'POST',
        body: JSON.stringify({ menu_item_id: itemId, quantity: 1 })
      });
      
      if (data.success) {
        updateCartCount();
        showNotification(`${item.name} added to cart!`);
      } else {
        showNotification(data.message || 'Failed to add item to cart');
      }
    } catch (error) {
      console.error('Add to cart error:', error);
      // Fallback to localStorage if database fails
      const existingItem = cart.find(cartItem => cartItem.id === itemId);
      
      if (existingItem) {
        existingItem.quantity = (existingItem.quantity || 1) + 1;
      } else {
        cart.push({ ...item, quantity: 1 });
      }
      
      localStorage.setItem('cart', JSON.stringify(cart));
      updateCartCount();
      showNotification(`${item.name} added to cart!`);
    }
  }
}

// Update cart count in the UI
async function updateCartCount() {
  if (!cartCount) return;
  
  const userLoggedIn = isLoggedIn();
  
  if (!userLoggedIn) {
    // Use localStorage for guest users
    const totalItems = cart.reduce((total, item) => total + (item.quantity || 1), 0);
    cartCount.textContent = totalItems;
    cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
  } else {
    // Fetch from database for logged-in users
    try {
      const data = await apiCall('/cart');
      if (data.success) {
        const count = data.cartItems.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = count;
        cartCount.style.display = count > 0 ? 'flex' : 'none';
      }
    } catch (error) {
      console.error('Failed to update cart count:', error);
      // Fallback to localStorage
      const totalItems = cart.reduce((total, item) => total + (item.quantity || 1), 0);
      cartCount.textContent = totalItems;
      cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
    }
  }
}

// Show notification
function showNotification(message) {
  // Create notification element if it doesn't exist
  let notification = document.querySelector('.notification');
  
  if (!notification) {
    notification = document.createElement('div');
    notification.className = 'notification';
    document.body.appendChild(notification);
  }
  
  // Set message and show notification
  notification.textContent = message;
  notification.classList.add('show');
  
  // Hide after 3 seconds
  setTimeout(() => {
    notification.classList.remove('show');
  }, 3000);
}
function generateStars(rating) {
  let stars = '';
  for (let i = 0; i < 5; i++) {
    if (i < rating) {
      stars += '<i class="ri-star-fill"></i>';
    } else {
      stars += '<i class="ri-star-line"></i>';
    }
  }
  return stars;
}

// Update user info display
function updateUserInfo() {
  const userNameEl = document.getElementById('user-name');
  const logoutBtn = document.getElementById('logout-btn');
  
  const userLoggedIn = isLoggedIn();
  
  if (userNameEl && userLoggedIn) {
    const user = getUserData();
    if (user && user.name) {
      userNameEl.textContent = user.name;
    }
  }
  
  // Show/hide logout button based on login status
  if (logoutBtn) {
    logoutBtn.style.display = userLoggedIn ? 'block' : 'none';
  }
}

// Setup logout functionality
function setupLogout() {
  const logoutBtn = document.getElementById('logout-btn');
  
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to logout?')) {
        logout();
      }
    });
  }
}
