// Import API configuration
import { API_URL, isLoggedIn, getAuthToken, getUserData, apiCall } from './config.js';

const ordersList = document.getElementById('orders-list');

// Check authentication on page load
if (!isLoggedIn()) {
  console.warn('⚠️ User not logged in, redirecting to login page');
  alert('Please login to view your orders');
  window.location.href = '/pages/login.html';
}

// Load orders when page loads
document.addEventListener('DOMContentLoaded', () => {
  loadOrders();
});

// Load orders from database (only for logged-in users)
async function loadOrders() {
  console.log('📦 Loading orders...');
  
  if (!isLoggedIn()) {
    console.error('❌ User not logged in');
    showLoginRequired();
    return;
  }

  const user = getUserData();
  console.log('👤 Loading orders for user:', user?.email);

  // Show loading state
  ordersList.innerHTML = `
    <div class="loading-orders">
      <i class="ri-loader-4-line" style="font-size: 3rem; color: var(--primary-color); animation: spin 1s linear infinite;"></i>
      <p>Loading your orders...</p>
    </div>
  `;

  try {
    const data = await apiCall('/orders');
    
    console.log('📥 Orders response:', data);
    
    if (data.success && data.orders && data.orders.length > 0) {
      console.log(`✅ Loaded ${data.orders.length} orders`);
      displayOrders(data.orders);
    } else {
      console.log('ℹ️ No orders found');
      showEmptyOrders();
    }
  } catch (error) {
    console.error('❌ Failed to load orders:', error);
    
    // Check if it's an authentication error
    if (error.message.includes('401') || error.message.includes('Session expired')) {
      showLoginRequired();
    } else {
      showErrorState(error.message);
    }
  }
}

// Display orders
function displayOrders(orders) {
  ordersList.innerHTML = orders.map(order => {
    // Handle both database format (items as JSON string) and localStorage format (items as array)
    let items = [];
    if (typeof order.items === 'string') {
      try {
        items = JSON.parse(order.items);
      } catch (e) {
        items = [];
      }
    } else if (Array.isArray(order.items)) {
      items = order.items;
    }
    
    // Handle different date formats
    const orderDate = new Date(order.created_at || order.date).toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    return `
      <div class="order-card">
        <div class="order-header">
          <div>
            <div class="order-id">Order #${order.id}</div>
            <div class="order-date">${orderDate}</div>
          </div>
          <span class="order-status status-${order.status}">${formatStatus(order.status)}</span>
        </div>
        
        <div class="order-items">
          ${items.map(item => `
            <div class="order-item">
              <span class="order-item-name">${item.name}<span class="order-item-qty">× ${item.quantity}</span></span>
              <span>₹${(item.price * item.quantity).toFixed(2)}</span>
            </div>
          `).join('')}
        </div>
        
        <div class="order-footer">
          <div>
            <div class="order-total">Total: ₹${parseFloat(order.total_amount || order.total).toFixed(2)}</div>
            <div class="order-address">
              <i class="ri-map-pin-line"></i> ${order.delivery_address || order.deliveryAddress}
            </div>
            <div class="order-address">
              <i class="ri-time-line"></i> ${new Date(order.delivery_time || order.deliveryTime).toLocaleString('en-IN')}
            </div>
            <div class="order-address">
              <i class="ri-wallet-line"></i> ${(order.payment_method || order.paymentMethod) === 'cash' ? 'Cash on Delivery' : 'Online Payment'}
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Format status
function formatStatus(status) {
  const statusMap = {
    'pending': 'Pending',
    'preparing': 'Preparing',
    'out_for_delivery': 'Out for Delivery',
    'delivered': 'Delivered',
    'cancelled': 'Cancelled'
  };
  return statusMap[status] || status;
}

// Show empty orders
function showEmptyOrders() {
  ordersList.innerHTML = `
    <div class="empty-orders" style="text-align: center; padding: 3rem;">
      <i class="ri-file-list-line" style="font-size: 5rem; color: #d1d5db; margin-bottom: 1rem;"></i>
      <h3 style="color: var(--text-dark); margin-bottom: 1rem;">No orders yet</h3>
      <p style="color: var(--text-light); margin-bottom: 2rem;">Start ordering your favorite dishes!</p>
      <a href="/pages/menu.html" class="btn">Browse Menu</a>
    </div>
  `;
}

// Show login required message
function showLoginRequired() {
  ordersList.innerHTML = `
    <div class="empty-orders" style="text-align: center; padding: 3rem;">
      <i class="ri-lock-line" style="font-size: 5rem; color: #ef4444; margin-bottom: 1rem;"></i>
      <h3 style="color: var(--text-dark); margin-bottom: 1rem;">Login Required</h3>
      <p style="color: var(--text-light); margin-bottom: 2rem;">Please login to view your orders</p>
      <a href="/pages/login.html" class="btn">Login Now</a>
    </div>
  `;
}

// Show error state
function showErrorState(errorMessage) {
  ordersList.innerHTML = `
    <div class="empty-orders" style="text-align: center; padding: 3rem;">
      <i class="ri-error-warning-line" style="font-size: 5rem; color: #f59e0b; margin-bottom: 1rem;"></i>
      <h3 style="color: var(--text-dark); margin-bottom: 1rem;">Failed to Load Orders</h3>
      <p style="color: var(--text-light); margin-bottom: 1rem;">${errorMessage}</p>
      <button onclick="location.reload()" class="btn">Try Again</button>
    </div>
  `;
}

// Add CSS for loading animation
const style = document.createElement('style');
style.textContent = `
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  .loading-orders {
    text-align: center;
    padding: 3rem;
    color: var(--text-light);
  }
`;
document.head.appendChild(style);
