document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners to all "Add to Cart" buttons
    const addToCartButtons = document.querySelectorAll('.special__card .btn');
    
    // Map item names to IDs (should match menu.js)
    const itemMap = {
        'Chicken kabab': 9,
        'Mutton pepper-Fry': 10,
        'Prawns biryani': 11,
        'Apollo Fish': 4,
        'Paneer Biryani': 2,
        'Mutton Biryani': 3,
        'Chicken Tikka Wrap': 7
    };
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const card = this.closest('.special__card');
            const itemName = card.querySelector('h4').textContent;
            const itemPrice = parseFloat(card.querySelector('.price').textContent.replace('₹', '').trim());
            const itemImage = card.querySelector('img').src;
            const itemId = itemMap[itemName] || 1;
            
            // Create a cart item object
            const item = {
                id: itemId,
                name: itemName,
                price: itemPrice,
                image_url: itemImage,
                quantity: 1
            };
            
            // Add to cart
            addToCart(item);
            
            // Show success message
            showNotification(`${itemName} added to cart!`);
        });
    });
    
    // Function to add item to cart
    async function addToCart(item) {
        // Check if user is logged in
        const isLoggedIn = !!localStorage.getItem('token');
        
        if (!isLoggedIn) {
            // Use localStorage for guest users
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const existingItem = cart.find(cartItem => cartItem.id === item.id);
            
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push(item);
            }
            
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCartCount();
            
            // Dispatch event to notify other scripts
            window.dispatchEvent(new Event('cartUpdated'));
        } else {
            // Use database for logged-in users
            try {
                const response = await fetch('http://localhost:5000/api/cart/add', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify({
                        menu_item_id: item.id,
                        quantity: 1
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    updateCartCount();
                    // Dispatch event to notify other scripts
                    window.dispatchEvent(new Event('cartUpdated'));
                } else {
                    console.error('Failed to add item to cart:', data.message);
                    showNotification('Failed to add item to cart');
                }
            } catch (error) {
                console.error('Error adding item to cart:', error);
                // Fallback to localStorage
                let cart = JSON.parse(localStorage.getItem('cart')) || [];
                const existingItem = cart.find(cartItem => cartItem.id === item.id);
                
                if (existingItem) {
                    existingItem.quantity += 1;
                } else {
                    cart.push(item);
                }
                
                localStorage.setItem('cart', JSON.stringify(cart));
                updateCartCount();
                // Dispatch event to notify other scripts
                window.dispatchEvent(new Event('cartUpdated'));
            }
        }
    }
    
    // Function to update cart count
    async function updateCartCount() {
        const cartCountEl = document.getElementById('cart-count');
        if (!cartCountEl) return;
        
        const isLoggedIn = !!localStorage.getItem('token');
        
        if (!isLoggedIn) {
            // Use localStorage for guest users
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const count = cart.reduce((total, item) => total + (item.quantity || 1), 0);
            cartCountEl.textContent = count;
            cartCountEl.style.display = count > 0 ? 'flex' : 'none';
        } else {
            // Fetch from database for logged-in users
            try {
                const response = await fetch('http://localhost:5000/api/cart', {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    const count = data.cartItems.reduce((total, item) => total + item.quantity, 0);
                    cartCountEl.textContent = count;
                    cartCountEl.style.display = count > 0 ? 'flex' : 'none';
                }
            } catch (error) {
                console.error('Error updating cart count:', error);
            }
        }
    }
    
    // Function to show notification
    function showNotification(message) {
        // Create notification element if it doesn't exist
        let notification = document.querySelector('.notification');
        
        if (!notification) {
            notification = document.createElement('div');
            notification.className = 'notification';
            document.body.appendChild(notification);
            
            // Add styles if they don't exist
            if (!document.getElementById('notification-styles')) {
                const style = document.createElement('style');
                style.id = 'notification-styles';
                style.textContent = `
                    .notification {
                        position: fixed;
                        bottom: 20px;
                        right: 20px;
                        background-color: #4CAF50;
                        color: white;
                        padding: 15px 25px;
                        border-radius: 4px;
                        font-size: 16px;
                        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                        z-index: 1000;
                        transform: translateY(100px);
                        opacity: 0;
                        transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
                    }
                    
                    .notification.show {
                        transform: translateY(0);
                        opacity: 1;
                    }
                `;
                document.head.appendChild(style);
            }
        }
        
        // Set message and show notification
        notification.textContent = message;
        notification.classList.add('show');
        
        // Hide after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    // Initialize cart count on page load
    updateCartCount();
});
