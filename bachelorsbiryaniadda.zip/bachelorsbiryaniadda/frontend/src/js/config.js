// API Configuration
// Use relative URL in production, localhost in development
const isLocalhost = window.location.hostname === 'localhost' || 
                    window.location.hostname === '127.0.0.1' ||
                    window.location.hostname === '';

export const API_URL = isLocalhost
  ? 'http://localhost:5000/api' 
  : '/api';

// Helper function to get auth token
export function getAuthToken() {
  return localStorage.getItem('token');
}

// Helper function to get user data
export function getUserData() {
  const userData = localStorage.getItem('user');
  return userData ? JSON.parse(userData) : null;
}

// Helper function to check if user is logged in
export function isLoggedIn() {
  return !!getAuthToken();
}

// Helper function to logout
export function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = '../pages/login.html';
}

// Helper function to make authenticated API calls
export async function apiCall(endpoint, options = {}) {
  const token = getAuthToken();
  
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers
    });
    
    // Try to parse JSON response
    let data;
    try {
      data = await response.json();
    } catch (parseError) {
      console.error('Failed to parse response:', parseError);
      throw new Error('Invalid server response');
    }
    
    if (!response.ok) {
      if (response.status === 401) {
        // Token expired or invalid
        logout();
        throw new Error('Session expired. Please login again.');
      }
      
      // Log detailed error information
      console.error('API request failed:', {
        endpoint,
        status: response.status,
        statusText: response.statusText,
        message: data.message,
        data
      });
      
      throw new Error(data.message || `API request failed with status ${response.status}`);
    }
    
    return data;
  } catch (error) {
    console.error('API Error:', error);
    
    // Provide more helpful error messages
    if (error.message === 'Failed to fetch') {
      throw new Error('Cannot connect to server. Please ensure the server is running.');
    }
    
    throw error;
  }
}

// Check authentication on protected pages
export function requireAuth() {
  if (!isLoggedIn()) {
    window.location.href = '../pages/login.html';
  }
}
