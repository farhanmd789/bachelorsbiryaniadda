// Navigation menu toggle
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.getElementById("nav-links");
const menuBtnIcon = menuBtn.querySelector("i");

menuBtn.addEventListener("click", (e) => {
  navLinks.classList.toggle("open");
  const isOpen = navLinks.classList.contains("open");
  menuBtnIcon.setAttribute("class", isOpen ? "ri-close-line" : "ri-menu-line");
});

navLinks.addEventListener("click", (e) => {
  navLinks.classList.remove("open");
  menuBtnIcon.setAttribute("class", "ri-menu-line");
});

// ScrollReveal animations
const scrollRevealOption = {
  distance: "50px",
  origin: "bottom",
  duration: 1000,
};

// Initialize ScrollReveal if available
if (typeof ScrollReveal !== 'undefined') {
  ScrollReveal().reveal(".header__image img", {
    ...scrollRevealOption,
    origin: "right",
  });
  ScrollReveal().reveal(".header__content h1", {
    ...scrollRevealOption,
    delay: 500,
  });
  ScrollReveal().reveal(".header__content .section__description", {
    ...scrollRevealOption,
    delay: 1000,
  });
  ScrollReveal().reveal(".header__content .header__btn", {
    ...scrollRevealOption,
    delay: 1500,
  });

  ScrollReveal().reveal(".explore__image img", {
    ...scrollRevealOption,
    origin: "left",
  });
  ScrollReveal().reveal(".explore__content .section__header", {
    ...scrollRevealOption,
    delay: 500,
  });
  ScrollReveal().reveal(".explore__content .section__description", {
    ...scrollRevealOption,
    delay: 1000,
  });
  ScrollReveal().reveal(".explore__content .explore__btn", {
    ...scrollRevealOption,
    delay: 1500,
  });

  ScrollReveal().reveal(".banner__card", {
    ...scrollRevealOption,
    interval: 500,
  });
}

// Initialize Swiper if available
if (typeof Swiper !== 'undefined') {
  const swiper = new Swiper(".swiper", {
    loop: true,
    pagination: {
      el: ".swiper-pagination",
    },
  });
}

// Update cart count on page load
function updateCartCountOnLoad() {
  const cartCountEl = document.getElementById('cart-count');
  if (!cartCountEl) return;
  
  const isLoggedIn = !!localStorage.getItem('token');
  
  if (!isLoggedIn) {
    // Use localStorage for guest users
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const count = cart.reduce((total, item) => total + (item.quantity || 1), 0);
    cartCountEl.textContent = count;
    cartCountEl.style.display = count > 0 ? 'flex' : 'none';
  } else {
    // Fetch from database for logged-in users
    fetch('http://localhost:5000/api/cart', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const count = data.cartItems.reduce((total, item) => total + item.quantity, 0);
        cartCountEl.textContent = count;
        cartCountEl.style.display = count > 0 ? 'flex' : 'none';
      }
    })
    .catch(error => {
      console.error('Error updating cart count:', error);
      // Fallback to localStorage
      const cart = JSON.parse(localStorage.getItem('cart')) || [];
      const count = cart.reduce((total, item) => total + (item.quantity || 1), 0);
      cartCountEl.textContent = count;
      cartCountEl.style.display = count > 0 ? 'flex' : 'none';
    });
  }
}

// Update user info display
function updateUserInfo() {
  const userInfoEl = document.getElementById('user-info');
  const userNameEl = document.getElementById('user-name');
  const authBtn = document.getElementById('auth-btn');
  const logoutBtn = document.getElementById('logout-btn');
  
  const isLoggedIn = !!localStorage.getItem('token');
  
  if (isLoggedIn) {
    // User is logged in
    const userData = localStorage.getItem('user');
    if (userData) {
      try {
        const user = JSON.parse(userData);
        if (userNameEl) {
          userNameEl.textContent = user.name || 'User';
        }
      } catch (e) {
        console.error('Error parsing user data:', e);
      }
    }
    
    // Show user info and logout button, hide login button
    if (userInfoEl) userInfoEl.style.display = 'flex';
    if (logoutBtn) logoutBtn.style.display = 'block';
    if (authBtn) authBtn.style.display = 'none';
  } else {
    // User is not logged in
    if (userInfoEl) userInfoEl.style.display = 'none';
    if (logoutBtn) logoutBtn.style.display = 'none';
    if (authBtn) authBtn.style.display = 'block';
  }
}

// Handle logout
function handleLogout() {
  if (confirm('Are you sure you want to logout?')) {
    // Clear authentication data
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    
    // Show success message
    alert('Logged out successfully!');
    
    // Redirect to login page
    window.location.href = 'pages/login.html';
  }
}

// Setup logout button
function setupLogout() {
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', handleLogout);
  }
}

// Initialize everything when page loads
document.addEventListener('DOMContentLoaded', function() {
  updateCartCountOnLoad();
  updateUserInfo();
  setupLogout();
});

// Listen for cart updates from menu-cart.js
window.addEventListener('cartUpdated', updateCartCountOnLoad);
