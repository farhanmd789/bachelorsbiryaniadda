// This file is deprecated - functionality moved to js/main.js
// Keeping for backward compatibility

// Smooth scroll for order button
document.addEventListener('DOMContentLoaded', function() {
  const orderBtn = document.querySelector(".header__btn .btn");
  const ordersSection = document.getElementById("delivery");

  if (orderBtn && ordersSection) {
    orderBtn.addEventListener("click", function (e) {
      e.preventDefault();
      ordersSection.scrollIntoView({ behavior: "smooth" });
    });
  }
});
