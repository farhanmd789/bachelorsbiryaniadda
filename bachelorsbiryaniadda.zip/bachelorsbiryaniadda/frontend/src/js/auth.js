// Import API configuration
import { API_URL } from './config.js';

// Wait for DOM to be ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAuth);
} else {
  initAuth();
}

function initAuth() {
  // Check if on login page
  if (window.location.pathname.includes('login.html')) {
    initLoginPage();
  }
  
  // Check if on register page
  if (window.location.pathname.includes('register.html')) {
    initRegisterPage();
  }
}

// ============================================
// LOGIN PAGE FUNCTIONALITY
// ============================================
function initLoginPage() {
  const loginForm = document.getElementById('login-form');
  const errorMessage = document.getElementById('error-message');
  const successMessage = document.getElementById('success-message');
  const submitBtn = loginForm.querySelector('button[type="submit"]');

  if (!loginForm) {
    console.error('Login form not found');
    return;
  }

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Get form values
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    
    // Validate inputs
    if (!email || !password) {
      showError(errorMessage, 'Please enter both email and password');
      return;
    }
    
    if (!isValidEmail(email)) {
      showError(errorMessage, 'Please enter a valid email address');
      return;
    }
    
    // Disable submit button
    submitBtn.disabled = true;
    submitBtn.textContent = 'Logging in...';
    
    try {
      console.log('🔐 Attempting login...');
      console.log('📡 API URL:', `${API_URL}/auth/login`);
      
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });
      
      console.log('📥 Response status:', response.status);
      
      const data = await response.json();
      console.log('📦 Response data:', data);
      
      if (response.ok && data.success) {
        // Store authentication data
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        
        console.log('✅ Login successful!');
        
        // Sync cart if exists
        try {
          await syncCartToDatabase();
        } catch (syncError) {
          console.warn('⚠️ Cart sync failed (non-critical):', syncError);
        }
        
        // Show success message
        showSuccess(successMessage, 'Login successful! Redirecting...');
        hideError(errorMessage);
        
        // Redirect to home page
        setTimeout(() => {
          window.location.href = '/';
        }, 1500);
      } else {
        throw new Error(data.message || 'Login failed. Please check your credentials.');
      }
    } catch (error) {
      console.error('❌ Login error:', error);
      
      let errorMsg = 'Login failed. ';
      
      if (error.message.includes('Failed to fetch')) {
        errorMsg += 'Cannot connect to server. Please make sure the backend is running.';
      } else {
        errorMsg += error.message;
      }
      
      showError(errorMessage, errorMsg);
      hideSuccess(successMessage);
    } finally {
      // Re-enable submit button
      submitBtn.disabled = false;
      submitBtn.textContent = 'Login';
    }
  });
}

// ============================================
// REGISTER PAGE FUNCTIONALITY
// ============================================
function initRegisterPage() {
  const registerForm = document.getElementById('register-form');
  const errorMessage = document.getElementById('error-message');
  const successMessage = document.getElementById('success-message');
  const submitBtn = registerForm.querySelector('button[type="submit"]');

  if (!registerForm) {
    console.error('Register form not found');
    return;
  }

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    // Validate inputs
    if (!name || !email || !password || !confirmPassword) {
      showError(errorMessage, 'Please fill in all required fields');
      return;
    }
    
    if (name.length < 2) {
      showError(errorMessage, 'Name must be at least 2 characters long');
      return;
    }
    
    if (!isValidEmail(email)) {
      showError(errorMessage, 'Please enter a valid email address');
      return;
    }
    
    if (password.length < 6) {
      showError(errorMessage, 'Password must be at least 6 characters long');
      return;
    }
    
    if (password !== confirmPassword) {
      showError(errorMessage, 'Passwords do not match!');
      return;
    }
    
    if (phone && !isValidPhone(phone)) {
      showError(errorMessage, 'Please enter a valid phone number');
      return;
    }
    
    // Disable submit button
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating Account...';
    
    try {
      console.log('📝 Attempting registration...');
      console.log('📡 API URL:', `${API_URL}/auth/register`);
      
      const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ name, email, phone, password })
      });
      
      console.log('📥 Response status:', response.status);
      
      const data = await response.json();
      console.log('📦 Response data:', data);
      
      if (response.ok && data.success) {
        // Store authentication data
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        
        console.log('✅ Registration successful!');
        
        // Sync cart if exists
        try {
          await syncCartToDatabase();
        } catch (syncError) {
          console.warn('⚠️ Cart sync failed (non-critical):', syncError);
        }
        
        // Show success message
        showSuccess(successMessage, 'Registration successful! Redirecting...');
        hideError(errorMessage);
        
        // Redirect to home page
        setTimeout(() => {
          window.location.href = '/';
        }, 1500);
      } else {
        throw new Error(data.message || 'Registration failed. Please try again.');
      }
    } catch (error) {
      console.error('❌ Registration error:', error);
      
      let errorMsg = 'Registration failed. ';
      
      if (error.message.includes('Failed to fetch')) {
        errorMsg += 'Cannot connect to server. Please make sure the backend is running.';
      } else {
        errorMsg += error.message;
      }
      
      showError(errorMessage, errorMsg);
      hideSuccess(successMessage);
    } finally {
      // Re-enable submit button
      submitBtn.disabled = false;
      submitBtn.textContent = 'Register';
    }
  });
}

// ============================================
// HELPER FUNCTIONS
// ============================================

// Validate email format
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Validate phone format
function isValidPhone(phone) {
  const phoneRegex = /^[0-9]{10}$/;
  return phoneRegex.test(phone.replace(/[\s-]/g, ''));
}

// Show error message
function showError(element, message) {
  if (element) {
    element.textContent = message;
    element.style.display = 'block';
  }
}

// Hide error message
function hideError(element) {
  if (element) {
    element.style.display = 'none';
  }
}

// Show success message
function showSuccess(element, message) {
  if (element) {
    element.textContent = message;
    element.style.display = 'block';
  }
}

// Hide success message
function hideSuccess(element) {
  if (element) {
    element.style.display = 'none';
  }
}

// Sync localStorage cart to database after login/register
async function syncCartToDatabase() {
  try {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    if (cart.length === 0) {
      console.log('📦 No cart items to sync');
      return;
    }
    
    console.log(`📦 Syncing ${cart.length} cart items to database...`);
    
    const token = localStorage.getItem('token');
    if (!token) {
      console.warn('⚠️ No token found, skipping cart sync');
      return;
    }
    
    // Add each cart item to database
    for (const item of cart) {
      try {
        const response = await fetch(`${API_URL}/cart/add`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            menu_item_id: item.id,
            quantity: item.quantity || 1
          })
        });
        
        if (response.ok) {
          console.log(`✅ Synced item: ${item.name}`);
        }
      } catch (error) {
        console.error(`❌ Failed to sync item ${item.name}:`, error);
      }
    }
    
    // Clear localStorage cart after successful sync
    localStorage.removeItem('cart');
    console.log('✅ Cart sync completed');
  } catch (error) {
    console.error('❌ Cart sync failed:', error);
    throw error;
  }
}
