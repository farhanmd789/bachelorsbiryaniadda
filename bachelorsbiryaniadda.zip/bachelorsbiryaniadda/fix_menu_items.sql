-- Quick fix: Insert missing menu items
USE bachelorsbiryani_db;

-- First, check what menu items exist
SELECT 'Current menu items:' as info;
SELECT id, name FROM menu_items ORDER BY id;

-- Insert all menu items (INSERT IGNORE will skip if ID already exists)
INSERT IGNORE INTO menu_items (id, name, description, price, category, image_url, is_available) VALUES
(1, 'Chicken Biryani', 'Fragrant basmati rice cooked with tender chicken pieces and aromatic spices', 250.00, 'biryani', '../IMAGES/biryani.png', 1),
(2, 'Paneer Biryani', 'Aromatic basmati rice layered with marinated paneer cubes and fresh vegetables', 249.00, 'biryani', '../IMAGES/paneerbiryani.png', 1),
(3, 'Mutton Biryani', 'Premium mutton pieces slow-cooked with aromatic basmati rice and spices', 379.00, 'biryani', '../IMAGES/muttonbiryani.png', 1),
(4, 'Apollo Fish', 'Crispy fried fish tossed in spicy tangy sauce with curry leaves', 299.00, 'starter', '../IMAGES/apollofish.jpg', 1),
(5, 'Butter Naan', 'Soft and buttery tandoor-baked flatbread', 30.00, 'bread', '../IMAGES/butternaanwhitebg.jpg', 1),
(6, 'Egg Biryani', 'Flavorful biryani with boiled eggs, aromatic spices and basmati rice', 180.00, 'biryani', '../IMAGES/eggbiryaniwhitebg.jpg', 1),
(7, 'Chicken Tikka Wrap', 'Soft tortilla wrap filled with grilled chicken tikka and fresh vegetables', 189.00, 'starter', '../IMAGES/bachelorshawarma.png', 1),
(8, 'Veg Biryani', 'Delicious biryani made with fresh vegetables and aromatic spices', 180.00, 'biryani', '../IMAGES/biryani.png', 1),
(9, 'Chicken kabab', 'Succulent pieces of chicken grilled over charcoal', 279.00, 'starter', '../IMAGES/kebab.png', 1),
(10, 'Mutton pepper-Fry', 'Spicy and flavorful mutton pieces with pepper', 329.00, 'starter', '../IMAGES/mutton-pepper-fry.png', 1),
(11, 'Prawns biryani', 'Savory rice dish infused with spicy marinated prawns', 269.00, 'biryani', '../IMAGES/prawn biryani.jpg', 1);

-- Verify all items are now present
SELECT 'After insert:' as info;
SELECT id, name, price FROM menu_items ORDER BY id;

SELECT CONCAT('✅ Total menu items: ', COUNT(*)) as result FROM menu_items;
