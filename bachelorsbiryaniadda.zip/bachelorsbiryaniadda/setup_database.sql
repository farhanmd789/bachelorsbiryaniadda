-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS bachelorsbiryani_db;

-- Use the database
USE bachelorsbiryani_db;

-- Create menu_items table if it doesn't exist
CREATE TABLE IF NOT EXISTS menu_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  image_url VARCHAR(255),
  category VARCHAR(50),
  rating DECIMAL(3,1) DEFAULT 0,
  in_stock BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Check if the table is empty
SET @row_count = (SELECT COUNT(*) FROM menu_items);

-- Insert sample data if table is empty
INSERT INTO menu_items (name, description, price, image_url, category, rating) 
SELECT * FROM (
  SELECT 'Chicken Biryani' as name, 'Fragrant basmati rice cooked with tender chicken pieces and aromatic spices' as description, 250.00 as price, '/IMAGES/chicken-biryani.jpg' as image_url, 'Biryani' as category, 4.5 as rating
  UNION ALL
  SELECT 'Paneer Biryani', 'Aromatic basmati rice with marinated paneer cubes and fresh vegetables', 220.00, '/IMAGES/paneer-biryani.jpg', 'Biryani', 4.2
  UNION ALL
  SELECT 'Mutton Biryani', 'Premium basmati rice with tender mutton pieces and rich spices', 320.00, '/IMAGES/mutton-biryani.jpg', 'Biryani', 4.7
  UNION ALL
  SELECT 'Veg Biryani', 'Delicious biryani made with fresh vegetables and aromatic spices', 180.00, '/IMAGES/veg-biryani.jpg', 'Biryani', 4.0
  UNION ALL
  SELECT 'Chicken Tikka', 'Tender chicken pieces marinated in spices and grilled to perfection', 280.00, '/IMAGES/chicken-tikka.jpg', 'Starter', 4.3
  UNION ALL
  SELECT 'Paneer Tikka', 'Cubes of paneer marinated in spices and grilled', 240.00, '/IMAGES/paneer-tikka.jpg', 'Starter', 4.1
  UNION ALL
  SELECT 'Butter Naan', 'Soft and buttery tandoor-baked flatbread', 30.00, '/IMAGES/butter-naan.jpg', 'Bread', 4.5
  UNION ALL
  SELECT 'Raita', 'Cooling yogurt with cucumber and spices', 40.00, '/IMAGES/raita.jpg', 'Side Dish', 4.0
) AS new_items
WHERE @row_count = 0;

-- Verify the data was inserted
SELECT 'Menu items count:' as message, COUNT(*) as count FROM menu_items;
