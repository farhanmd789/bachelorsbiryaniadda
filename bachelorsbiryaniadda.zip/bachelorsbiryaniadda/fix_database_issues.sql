-- Fix database issues for bachelorsbiryani_db
USE bachelorsbiryani_db;

-- 1. Add in_stock column if it doesn't exist (for older schema)
-- Check if column exists first, then add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'bachelorsbiryani_db' 
AND TABLE_NAME = 'menu_items' 
AND COLUMN_NAME = 'in_stock';

SET @query = IF(@col_exists = 0, 
    'ALTER TABLE menu_items ADD COLUMN in_stock BOOLEAN DEFAULT true', 
    'SELECT "Column in_stock already exists" AS message');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 2. Update existing records to have in_stock = true
UPDATE menu_items SET in_stock = true WHERE in_stock IS NULL OR in_stock = 0;

-- 3. Fix image paths to match the actual frontend structure
UPDATE menu_items SET image_url = '/src/assets/images/biryani.png' WHERE image_url LIKE '%biryani.png' AND name LIKE '%Chicken%';
UPDATE menu_items SET image_url = '/src/assets/images/paneerbiryani.png' WHERE image_url LIKE '%paneerbiryani.png';
UPDATE menu_items SET image_url = '/src/assets/images/muttonbiryani.png' WHERE image_url LIKE '%muttonbiryani.png';
UPDATE menu_items SET image_url = '/src/assets/images/apollofish.jpg' WHERE image_url LIKE '%apollofish.jpg';
UPDATE menu_items SET image_url = '/src/assets/images/butternaanwhitebg.jpg' WHERE image_url LIKE '%butternaanwhitebg.jpg';
UPDATE menu_items SET image_url = '/src/assets/images/eggbiryaniwhitebg.jpg' WHERE image_url LIKE '%eggbiryaniwhitebg.jpg';
UPDATE menu_items SET image_url = '/src/assets/images/bachelorshawarma.png' WHERE image_url LIKE '%bachelorshawarma.png';
UPDATE menu_items SET image_url = '/src/assets/images/kebab.png' WHERE image_url LIKE '%chicken65.jpg' OR image_url LIKE '%kebab.png' OR name LIKE '%kabab%';
UPDATE menu_items SET image_url = '/src/assets/images/mutton-pepper-fry.png' WHERE image_url LIKE '%mutton-pepper-fry.png';
UPDATE menu_items SET image_url = '/src/assets/images/prawn biryani.jpg' WHERE name LIKE '%Prawn%';
UPDATE menu_items SET image_url = '/src/assets/images/biryani.png' WHERE name LIKE '%Veg%' AND name LIKE '%Biryani%';

-- 4. Verify the changes
SELECT id, name, image_url, in_stock FROM menu_items ORDER BY id;
