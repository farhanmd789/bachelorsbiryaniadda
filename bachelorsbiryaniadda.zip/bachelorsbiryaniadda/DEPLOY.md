# Render Deployment Instructions

## Prerequisites
1. MySQL database (use Render MySQL or external provider like PlanetScale, Railway, etc.)
2. Render account

## Steps to Deploy

### 1. Prepare Database
- Create a MySQL database on your preferred provider
- Note down the connection details (host, user, password, database name)
- Run the schema.sql file to create tables

### 2. Deploy to Render
1. Push code to GitHub repository
2. Go to Render Dashboard
3. Click "New +" → "Web Service"
4. Connect your GitHub repository
5. Configure:
   - **Name**: bachelorsbiryani-app
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`

### 3. Set Environment Variables in Render
Add these in the Environment section:
```
NODE_ENV=production
DB_HOST=your-mysql-host
DB_USER=your-mysql-user
DB_PASSWORD=your-mysql-password
DB_NAME=your-database-name
DB_PORT=3306
JWT_SECRET=generate-a-strong-random-secret-key
```

Or use DATABASE_URL format:
```
DATABASE_URL=mysql://user:password@host:3306/database
```

### 4. Deploy
- Click "Create Web Service"
- Wait for deployment to complete
- Your app will be available at: https://your-app-name.onrender.com

## Post-Deployment
1. Test the health endpoint: https://your-app-name.onrender.com/api/health
2. Create admin user via API or directly in database
3. Test login and order flow

## Troubleshooting
- Check logs in Render dashboard
- Verify database connection
- Ensure all environment variables are set correctly
