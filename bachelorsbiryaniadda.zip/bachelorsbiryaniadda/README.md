# Bachelors Biryani Adda - Full Stack Restaurant App

A complete full-stack restaurant web application with user authentication, menu management, shopping cart, and order tracking.

## Features

✅ **User Authentication**
- User registration and login
- JWT-based authentication
- Secure password hashing

✅ **Dynamic Menu**
- Browse menu items from database
- Category-based organization
- Real-time stock availability

✅ **Shopping Cart**
- Add/remove items
- Update quantities
- Persistent cart storage
- Price calculation with tax and delivery fee

✅ **Order Management**
- Place orders with delivery details
- View order history
- Track order status
- Admin dashboard for order management

## Tech Stack

**Frontend:**
- HTML5, CSS3, JavaScript (Vanilla)
- Responsive design
- Modern UI/UX

**Backend:**
- Node.js + Express.js
- MySQL database
- JWT authentication
- RESTful API

## Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- MySQL (v8 or higher)
- npm or yarn

### Step 1: Install Dependencies

```bash
npm install
```

### Step 2: Setup MySQL Database

1. Open MySQL Workbench or command line
2. Run the SQL schema file:

```bash
mysql -u root -p < server/config/schema.sql
```

Or manually:
- Open `server/config/schema.sql`
- Copy and execute all SQL commands in MySQL

### Step 3: Configure Environment Variables

1. Open `.env` file
2. Update the following:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=bachelorsbiryani_db
JWT_SECRET=your_secret_key_here
```

### Step 4: Start the Backend Server

```bash
npm start
```

Or for development with auto-reload:

```bash
npm run dev
```

Server will run on: `http://localhost:5000`

### Step 5: Open the Frontend

Open `index.html` in your browser or use a local server:

```bash
# Using Python
python -m http.server 8000

# Using Node.js http-server
npx http-server -p 8000
```

Then visit: `http://localhost:8000`

## Project Structure

```
landingpage/
├── server/
│   ├── config/
│   │   ├── database.js       # Database connection
│   │   └── schema.sql        # Database schema
│   ├── controllers/
│   │   ├── authController.js # Authentication logic
│   │   ├── menuController.js # Menu management
│   │   ├── cartController.js # Cart operations
│   │   └── orderController.js # Order processing
│   ├── routes/
│   │   ├── authRoutes.js     # Auth endpoints
│   │   ├── menuRoutes.js     # Menu endpoints
│   │   ├── cartRoutes.js     # Cart endpoints
│   │   └── orderRoutes.js    # Order endpoints
│   ├── middleware/
│   │   └── auth.js           # JWT verification
│   └── server.js             # Express server
├── pages/
│   ├── login.html            # Login page
│   ├── register.html         # Registration page
│   ├── menu.html             # Menu browsing
│   ├── cart.html             # Shopping cart
│   └── orders.html           # Order history
├── js/
│   ├── config.js             # API configuration
│   ├── auth.js               # Authentication logic
│   ├── menu.js               # Menu functionality
│   ├── cart.js               # Cart functionality
│   └── orders.js             # Orders functionality
├── IMAGES/                   # Image assets
├── index.html                # Landing page
├── styles.css                # Global styles
├── script.js                 # Landing page scripts
├── package.json              # Dependencies
└── .env                      # Environment variables
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/profile` - Get user profile (protected)

### Menu
- `GET /api/menu` - Get all menu items
- `GET /api/menu/:id` - Get single menu item
- `POST /api/menu` - Add menu item (admin only)
- `PUT /api/menu/:id` - Update menu item (admin only)
- `DELETE /api/menu/:id` - Delete menu item (admin only)

### Cart
- `GET /api/cart` - Get user's cart
- `POST /api/cart/add` - Add item to cart
- `PUT /api/cart/:id` - Update cart item quantity
- `DELETE /api/cart/:id` - Remove item from cart
- `DELETE /api/cart` - Clear entire cart

### Orders
- `POST /api/orders` - Create new order
- `GET /api/orders` - Get user's orders
- `GET /api/orders/:id` - Get single order
- `GET /api/orders/admin/all` - Get all orders (admin only)
- `PUT /api/orders/:id/status` - Update order status (admin only)

## Default Credentials

**Admin Account:**
- Email: `admin@bachelorsbiryani.com`
- Password: `admin123`

## Usage

1. **Register/Login**: Create an account or login
2. **Browse Menu**: View available dishes
3. **Add to Cart**: Select items and add to cart
4. **Checkout**: Provide delivery details and place order
5. **Track Orders**: View your order history and status

## Database Schema

- **users** - User accounts
- **menu_items** - Restaurant menu
- **cart** - Shopping cart items
- **orders** - Customer orders
- **order_items** - Order details

## Security Features

- Password hashing with bcrypt
- JWT token authentication
- Protected API routes
- SQL injection prevention
- CORS enabled

## Future Enhancements

- Payment gateway integration
- Real-time order tracking with Socket.io
- Email notifications
- Reviews and ratings
- Admin dashboard UI
- Image upload for menu items

## Author

Mohammed Farhan

## License

ISC
