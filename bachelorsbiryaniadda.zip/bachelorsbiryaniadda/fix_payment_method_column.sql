-- Fix orders table - add payment_method column if it doesn't exist
USE bachelorsbiryani_db;

-- Check if column exists and add it if missing
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) AFTER status;

-- Verify the table structure
DESCRIBE orders;
