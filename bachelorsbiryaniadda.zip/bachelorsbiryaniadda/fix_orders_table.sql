-- Fix orders table: Add missing columns
USE bachelorsbiryani_db;

-- Check current structure
DESCRIBE orders;

-- Add missing columns if they don't exist
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) DEFAULT 'cash' AFTER status;

ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS delivery_time DATETIME AFTER delivery_address;

-- Verify the fix
DESCRIBE orders;

SELECT 'Orders table fixed successfully!' as message;
