const mysql = require('mysql2/promise');
require('dotenv').config();

async function fixOrdersTable() {
  let connection;
  
  try {
    // Create connection
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'bachelorsbiryani_db',
      port: 3306
    });

    console.log('✅ Connected to database');

    // Check current table structure
    console.log('\n📋 Current orders table structure:');
    const [columns] = await connection.query('DESCRIBE orders');
    console.table(columns);

    // Add payment_method column if it doesn't exist
    try {
      await connection.query(`
        ALTER TABLE orders 
        ADD COLUMN payment_method VARCHAR(50) DEFAULT 'cash' AFTER status
      `);
      console.log('✅ Added payment_method column');
    } catch (error) {
      if (error.code === 'ER_DUP_FIELDNAME') {
        console.log('ℹ️  payment_method column already exists');
      } else {
        throw error;
      }
    }

    // Add delivery_time column if it doesn't exist
    try {
      await connection.query(`
        ALTER TABLE orders 
        ADD COLUMN delivery_time DATETIME AFTER delivery_address
      `);
      console.log('✅ Added delivery_time column');
    } catch (error) {
      if (error.code === 'ER_DUP_FIELDNAME') {
        console.log('ℹ️  delivery_time column already exists');
      } else {
        throw error;
      }
    }

    // Verify the fix
    console.log('\n📋 Updated orders table structure:');
    const [updatedColumns] = await connection.query('DESCRIBE orders');
    console.table(updatedColumns);

    console.log('\n✅ Orders table fixed successfully!');

  } catch (error) {
    console.error('❌ Error fixing orders table:', error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

fixOrdersTable();
